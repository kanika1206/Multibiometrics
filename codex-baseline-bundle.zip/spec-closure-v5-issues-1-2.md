# Specification Closure v5 — Issues 1 & 2 (Review Rounds 1–4)
**Amends:** `protocol-spec-v2.md`, `protocol-spec-v3-amendments.md`, `experimental-plan-v4.md`. On conflict concerning Issues 1–3, this document wins.
**Status labels (read first — they are the honest core of this document):**
- **Issue 1 — SPECIFICATION CLOSED · TECHNICALLY OPEN.** The enforcement responsibilities, guarantees, non-guarantees and boundary tests are now precisely defined (§1). The issue may be marked *technically resolved* only when tests T-1a…T-1d have run on an implementation and their evidence is recorded.
- **Issue 2 — SPECIFICATION CLOSED · TECHNICALLY OPEN.** The review fields, canonical representation, binding flow and substitution tests are now defined (§2). Technically resolved only when tests S-1…S-4 have run and passed.
- **Issue 3 — CLOSED.** Frozen configuration (§3) applied consistently; alternative limits removed from normative text or labelled out of scope (cleanup performed with this revision).
**Closing a specification gap is not closing a security gap.** Nothing in this document upgrades any claim in the v2 Claims–Evidence Matrix; claims upgrade only on evidence, per v4.

---

## §1. Issue 1 — Joint enforcement of the multimodal requirement
### 1.1 The problem, restated exactly
Three different things are often conflated. The design assigns each to a different mechanism and never lets one impersonate another:
- **Key security** — can the private key be extracted? → Hardware-backed keystore. *Solved by platform.*
- **Use security** — can a signature be obtained *silently*, without a fresh act of the legitimate user? → Per-use platform gating of the key (v2 T1). *Enforced by the OS/keystore, provable by test T-1c.*
- **Policy security** — can the bank be sure the *custom face ∧ voice ∧ challenge pipeline genuinely passed* before the key was used? → **This is the hard one. No mechanism in this architecture proves it absolutely. §1.2 defines what is actually enforced, by whom; §1.3 states what is not guaranteed; §1.4 defines the tests that demonstrate the boundary.**

### 1.2 Who enforces what (normative)
| # | Enforcement duty | Enforcer | Mechanism (normative) |
|---|---|---|---|
| E1 | Only the **genuine, unmodified app binary** may obtain bank-accepted signatures | **Bank**, on platform evidence | Attestation verdict (Play Integrity / App Attest) is requested with its **nonce = hash of the bank's current challenge**, verified **server-side**, and **bound to that challenge/session**. A signature arriving without a fresh, passing, challenge-bound verdict is rejected at stage [3] regardless of signature validity. Verdicts are never accepted from client assertion. |
| E2 | No signature without a **fresh platform authentication event** by the device user, for *this* signing operation | **OS / keystore** | Device key is created with per-use user-authentication required (Android: `setUserAuthenticationRequired(true)`, validity = per-use, signing only via `BiometricPrompt` + `CryptoObject`; iOS: biometry-bound Secure Enclave key, `.biometryCurrentSet`). At registration the bank additionally verifies **key attestation** (Android key-attestation chain / App Attest) recording: hardware-backed, user-auth-required, per-use. A key lacking these properties is registered at reduced assurance and is ineligible for financial authorization. |
| E3 | The signing request is **assembled only on the pipeline's completion path**, and the signed payload commits to the pipeline's output | **App** (genuine binary — this duty is exactly as strong as E1) | Order is fixed: pipeline runs → transcript (scores, model versions, thresholds, per-layer verdicts, integrity signals, monotonic attempt timestamps) is finalised → canonical payload incl. `SHA-256(transcript)` is constructed → platform prompt (showing the §2 summary) releases the key → signature. There is no other call site for the signing function in the codebase (enforced by construction + code review checklist; stated as an engineering control, not a cryptographic one). |
| E4 | **Plausibility screening** of what the app reports | **Bank** | Stage [3]–[4] checks, all pre-registered: transcript model versions ∈ currently approved set · elapsed time between challenge issue and signature ≥ a floor consistent with actually running the pipeline (a sub-second challenge-to-signature round trip on a T1 flow is not a detection of fraud — it is an anomaly that forces step-up or denial per policy) · score patterns not degenerate (e.g. identical scores across attempts) · attempt counters and sequencing consistent. These are **detective** controls. The documents and the paper must call them that. |
| E5 | **Bounded consequence** if E1–E4 all fail simultaneously | **Bank policy** | Tier caps, per-transaction/daily limits, new-payee cooling (v3 Amendment 4), revocation. The system's answer to a perfect client-side bypass is that its blast radius is capped and audited — not that it is impossible. |

### 1.3 Non-guarantees (explicit limitations — to be quoted, not paraphrased away)
- **N1.** If the device's OS/attestation layer itself is compromised (e.g. rooted device with working attestation spoofing), **the bank cannot distinguish fabricated PASS verdicts from genuine ones.** Such devices are outside the strong guarantee. Where integrity signals indicate this state, policy is: financial authorization denied or restricted to T0 — the *signals available* decide, and the evaluation reports how often the state is correctly identified, without claiming it always is.
- **N2.** **The privacy property and this limitation are the same design choice viewed from two sides.** Proving the pipeline executed would require evidence about the biometric processing leaving the device (recordings, frames, or a trusted-execution proof that consumer phones do not offer for custom ML models — TEEs/StrongBox cannot run this ONNX pipeline, and no consumer platform offers remote attestation of arbitrary app ML execution). The architecture chose v4's P1 (no biometric data leaves the device). The price of that choice is N1, and it is paid openly: enforcement rests on *genuine binary (E1) + hardware-gated key use (E2) + server screening (E4) + bounded value at risk (E5)*.
- **N3.** Attestation proves (within the platform's own guarantees) *which binary ran and the device's integrity state at verdict time*. It does not prove the sensors saw a live person, that the models are good, or that the user understood the transaction (that is Issue 2). No project document may phrase E1 as "the bank verifies the biometrics."

### 1.4 Boundary tests (evidence required before "technically resolved")
Attacker models are separated, because the expected result differs by model — a test that lumps them proves nothing.
| Test | Attacker model & procedure | Expected result (the boundary, stated in advance) | Pass condition |
|---|---|---|---|
| **T-1a** | Modified app (forced PASS verdicts, genuine signing code path) on a **stock, unrooted** device; attempt login + transaction | Attestation verdict fails or does not match challenge nonce → bank rejects at stage [3] | 0 bank-accepted signatures across all attempts; rejection reason = attestation, recorded in audit. **This is the primary Issue-1 result.** |
| **T-1b** | Modified app **+ rooted device with attestation-spoofing tooling** | Outcome *measured, not presumed*: if spoofing succeeds, signatures may verify — the documented N1 boundary. Policy response (restriction/denial from integrity signals, caps) is then what is evaluated | Behaviour matches §1.2 E5 / §1.3 N1 policy exactly (whichever signals fire, the corresponding restriction is applied); the measured outcome is published whether flattering or not. The claim's boundary sentence is updated to the *measured* boundary |
| **T-1c** | Any app (modified or genuine) attempts to use the device key **without** a fresh platform auth event (direct keystore call, replayed prompt) | Keystore refuses; no signature exists to present | 0 signatures produced |
| **T-1d** | **Network attacker** (no device compromise) tampers with transcript/scores/verdicts in transit after a genuine (even failing) pipeline run | Signature covers the canonical payload incl. transcript hash → bank verification fails | 0 acceptances; reason = signature/payload mismatch |

## §2. Issue 2 — Transaction confirmation & consent binding
### 2.1 Distinction (normative wording)
The signature provides **cryptographic transaction integrity**: the bank can prove the authorized transaction is byte-identical to a specific proposal. **Informed user consent** — that the customer saw, read and intended those details — is a property of the *confirmation interface and flow*, established by §2.2–§2.4 as far as a prototype can, with the residual gap stated in §2.5. Documents must not use "the user approved X" where the evidence only supports "a signature over X exists."

### 2.2 The bank's Transaction Proposal is the single source of truth
The transaction is **created by the bank**, not assembled by the app: stage [1] returns a **Transaction Proposal** {`tx_id` (bank-generated), all fields in §2.3, challenge, expiry ≤ 5 min}. The app may *display* a proposal and may *request a new one*; it **cannot edit** one. Any change the user wants (different amount/payee) = discard proposal, request a new one. This eliminates the whole class of "app quietly rewrote the field after display" by construction — the app never holds an editable copy that signing trusts.

### 2.3 Exact review fields (confirmation screen — all mandatory, in this order, before biometric capture may start)
1. **Total debit amount** — most prominent element: `₹` + amount in Indian digit grouping + amount **in words** (e.g. "₹1,000 — One Thousand Rupees Only"). If fees ≠ 0, amount and fees are shown as separate lines *and* the total is the prominent figure; prototype fee = ₹0, field still rendered.
2. **Payee bank-registered name** — as held in the bank's payee registry (not the user's nickname; nickname, if any, shown secondarily, smaller).
3. **Payee identifier, masked** — account last-4 or UPI handle with masked local part, sufficient for the user to recognise the destination, insufficient to expose the full identifier on screen.
4. **Source account** — masked number + account type ("From: Savings ••••4821").
5. **Transaction type/purpose label** — e.g. "Transfer to another bank (IMPS)" in plain language.
6. **New-payee warning** — if this is the first transaction to this payee: a distinct banner ("First payment to this payee") + the T2 cooling notice where policy applies (v3 Amendment 4).
7. **Explicit confirmation action** — a deliberate tap ("Confirm & verify it's you") gates the start of biometric capture; no auto-advance, no countdown-confirm. Cancelling or timing out discards the proposal.
During the platform authentication prompt (Issue 1, E2/E3), the prompt's title/subtitle **repeats fields 1–2** ("Pay ₹1,000 to <registered payee name>"), generated from the proposal object — so the OS-level consent surface and the app screen show the same values from the same source.

### 2.4 Canonical representation & binding (normative)
- Amounts are **integer minor units (paise)** everywhere in proposals, payloads and signatures. No floats, no locale-formatted strings ever enter a signed field.
- Canonical signed bytes are the UTF-8 encoding of exactly:
 `TXN1|{tx_id}|{amount_paise}|{currency=INR}|{fees_paise}|{payee_id}|{payee_name_hash}|{src_acct_id}|{challenge}|{transcript_hash}`
 where `payee_name_hash = SHA-256` of the registry name normalised as: Unicode NFC → trim → collapse internal whitespace → as stored in the registry (normalisation applies to the *stored registry string*, never to user input at signing time).
- The bank, at stage [3], **recomputes the canonical bytes from its own proposal record** and compares against the signed bytes. It never trusts client-supplied field values for the comparison. Mismatch → DENIED, reason `payload_mismatch`.
- `proposal_display_hash`: the app includes in the (unsigned) session telemetry the hash of the exact field set it rendered; the bank logs it beside the proposal. (Detective control for display disputes — proves what the *genuine* app rendered; under a modified app it is only as strong as E1, and is labelled as such.)
### 2.5 Residual consent gap (explicit limitation)
A signature + a genuine app's confirmation screen still does not prove the user *read* the screen, and a compromised display path (malicious overlay/accessibility abuse on a compromised OS) can in principle show one thing while the genuine flow signs another. **Production** banking would need a trusted-display mechanism (e.g. Android Protected Confirmation / TEE trusted UI, where hardware-supported) — out of scope for the prototype, named here so the gap is a roadmap item and not a silent assumption. Prototype claim is limited to §2.1's wording.

### 2.6 Substitution tests (evidence required before "technically resolved")
| Test | Procedure | Expected / pass condition |
|---|---|---|
| **S-1** | Instrumented build: after the user confirms, mutate **amount** in the payload before signing (proposal untouched) | Bank recomputation mismatch → DENIED `payload_mismatch`; 0 executions |
| **S-2** | Same, mutating **payee_id / payee_name_hash** between confirmation and signing | Same as S-1 |
| **S-3** | Replay a *valid* signature from a confirmed ₹1,000-to-A proposal against a ₹50,000-to-B proposal (cross-proposal substitution) | Rejected: challenge/tx binding + canonical mismatch; 0 executions |
| **S-4** | UI-consistency test (automated): for a set of generated proposals incl. edge cases (large amounts, fees, new payee, long names), capture the confirmation screen + the platform-prompt subtitle and assert rendered fields 1–6 equal the proposal fields (incl. words rendering and Indian digit grouping) character-for-character after defined normalisation | 100% field equality across the generated set; any rendering truncation of payee name or amount = failure (layout must wrap, never ellipsize, fields 1–2) |

## §3. Issue 3 — Frozen offline configuration (restated once, normatively)
**Prototype offline financial authorization configuration — the only one used by the protocol, backend policy, test cases and evaluation:**
| Parameter | Frozen value |
|---|---|
| Financial pack validity | **48 hours** from issue |
| Max authorizations per pack | **5** |
| Per-transaction cap | **₹500** |
| Cumulative cap per pack | **₹2,000** |
| Local-access credential (Policy A) validity | 7 days (view/local unlock only; no financial authority) |
**Out of scope (explicitly):** the enhanced UPI Lite limits (₹1,000 / ₹5,000) and any other framework configuration are **not** prototype options and appear in project documents only as external background, labelled as such. Changing any frozen value re-opens the offline design review and invalidates P3 evidence gathered under the old configuration (v3 Amendment 2). The revocation-window limitation remains as documented: bounded by the table above, measured by the v2 headline test, **not eliminated**.

## §4. Freeze statement
With this revision, `protocol-spec-v2.md` (as amended), `protocol-spec-v3-amendments.md`, `experimental-plan-v4.md` and this document constitute **Specification Baseline 1.0** for implementation of the Issue-1/Issue-2 controls. Hashes are recorded in `FREEZE-RECORD.md`. Any later change to these files is a baseline change: it requires a new freeze record and re-opens any "specification closed" status it touches. Implementation and the T-/S-series tests proceed *against this baseline*; their results, not this document, will decide whether Issues 1 and 2 become **technically resolved**.
