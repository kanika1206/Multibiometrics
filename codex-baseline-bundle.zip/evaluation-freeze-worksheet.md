# Evaluation Freeze Worksheet — fill-in, do not edit the frozen specs

**Purpose:** Turn experimental-plan-v4 §6 (the freeze checklist) into a single fill-in
sheet. This worksheet is NOT part of Specification Baseline 1.0 and does NOT change
any frozen file. When every box below is filled and the bundle is hashed, copy the
`FREEZE:` line back into experimental-plan-v4 §6 — that is the moment headline
evaluations may start. Until then, no headline claim may be run.

**Rules copied from v4 §D.3 (do not relax these while filling this in):**
- After the freeze: no tuning on the held-out set, in either direction, ever.
  A change informed by held-out results converts that set into development data —
  it must be declared and a NEW held-out set created before any further headline claim.
- Any other deviation goes in the deviation log (§ below), with results reported
  both including and excluding affected trials where the deviation could matter.
- Solo arrangement (v4 §D.4): freeze + seal-by-hash substitutes for blinding.
  State the arrangement used: `solo / two-person (held-out generator ≠ threshold setter)`.

## 1. §6 checklist

- [ ] §A taxonomy implemented in the trial logger (outcome + denying/step-up control auto-recorded)
- [ ] §B configs B0–B5 runnable on the recorded corpus; reference device documented (§4 below)
- [ ] Table C1 reviewed against the ACTUAL code's data flows (not the intended ones)
- [ ] Threshold manifest (§2) + model manifest (§3) generated, SHA-256s recorded
- [ ] Held-out attack set generated/collected, hashed, sealed; development set listed separately (§5)
- [ ] Success criteria (§6) copied verbatim into the results template — claim cells are
      formulas over the criteria, not free text
- [ ] Freeze bundle committed & hashed; hash + date recorded: `FREEZE: ______ (date / bundle SHA-256)`

## 2. Threshold manifest (fill from the actual code/config at freeze time — do not guess)

| Threshold | Value | Source file / config key |
|---|---|---|
| Face identity (τf) | | |
| Speaker identity (τa) | | |
| PAD | | |
| Lip-sync | | |
| Risk / step-up | | |
| Tier policy (T0/T1/T2) | | |
| Challenge (digits / timeout) | | |

## 3. Model manifest (one row per model file, per config B0–B5)

| Config | Model | Source | Version | SHA-256 of model file |
|---|---|---|---|---|
| | | | | |
| | | | | |

## 4. Reference device + analysis code

| Item | Detail |
|---|---|
| Reference device (model / OS / RAM) | |
| Analysis code version (git commit) | |
| CI methods | Wilson / Clopper–Pearson for counts; subject-level bootstrap, seed 20261025, 5,000 replicates, for corpus metrics |
| Headline sample size | ≥300 attempts per headline attack class (v3 rule); a 0/30 result must be written as "0/30, 95% upper bound 9.5%", never as a bare 0% |

## 5. Attack sets — sealed held-out vs development (hash only, do not inspect held-out beyond inventory)

| Set | Attack class | Generation tool + version | Sample count | SHA-256 inventory location |
|---|---|---|---|---|
| Development | | | | |
| Held-out (SEALED) | | | | |

Held-out seal statement: the held-out samples have been inventoried by hash, not run,
and not inspected beyond inventory. Sealed by: ______ Date: ______

## 6. Pre-registered success criteria (from v4 §D.2 — copied, not edited)

- **P1:** §C tests 1–6 all pass (zero biometric artifacts found) AND transaction-substitution/
  replay tests: 0 altered-payload acceptances, 0 duplicate executions, across all trials run.
- **P2:** on the held-out set — (i) B5 attack acceptance ≤ B0 by ≥20 points, paired 95% CI
  excludes 0; (ii) B5 ≤ best single-layer config (B1–B3) by ≥5 points, paired CI excludes 0;
  (iii) cost budget: FRR(B5) − FRR(B0) ≤ +3 points, p95 latency increase ≤ +2.0 s,
  footprint ≤ 250 MB. If (i)+(ii) pass but (iii) fails, the pre-agreed wording is exactly:
  "P2 supported as a security result, not yet as a product improvement".
- **P3:** duplicate/replayed offline authorizations accepted by the bank: 0; rollback reuse
  accepted at sync: 0; revocation exposure measured and within 48 h / 5 / ₹2,000 in every
  revocation trial.
- **Tiers (C7):** 0 instances of a T0 session completing a T1/T2-reserved action without
  escalating; per-tier attack rows reported, incl. T0-aimed attacks.
- Any criterion not met is reported as not met, with the numbers.

## 7. Deviation log (use after the freeze only)

| Date | What changed | Why | Trials affected | Reported incl. / excl. |
|---|---|---|---|---|
| | | | | |

## 8. What this worksheet does NOT do

- It does not freeze anything by itself. Only a committed, hashed bundle + the
  `FREEZE:` line in experimental-plan-v4 §6 counts.
- It does not change Specification Baseline 1.0. Editing any baselined file breaks
  its hash and requires a new Baseline 1.1 record in FREEZE-RECORD.md.
