# FREEZE RECORD — Specification Baseline 1.0
**Frozen:** 25 Oct 2026 (IST), at the reviewer's direction: protocol and architecture documents revised together (Issues 1 & 2 specification closure + Issue 3 cleanup), then frozen **before** implementation of the Issue-1/Issue-2 security controls.
**Scope of baseline:** the documents below, at the SHA-256 hashes below. These hashes are the baseline; verify with `sha256sum` in this directory.

| Document | SHA-256 |
|---|---|
| `protocol-spec-v2.md` | `1fcada51425ffb22149d3b04d7479bfa83dfa2c5e52b228a7328a73737659386` |
| `protocol-spec-v3-amendments.md` | `3ff3363418b4ea634e1d3b916cefb09c5d79d76d2730df0bcd63697381f1b4ec` |
| `experimental-plan-v4.md` | `00f18688b3d57faf86ee0d74e3c1a78713492ac9d5e75c9f58e9769f8946ec73` |
| `spec-closure-v5-issues-1-2.md` | `a26ac3ac5f43aeb1e6cc164e2ed5f6cf53207e1619f011c24bbe3f9b1c3dbc74` |
| `prototype-architecture-bank.md` | `efd3be2d8f14a1dbd91303bccc1fb62def31a78be292d4f09a8288e8b21b8fdd` |
| `product-features-bank.md` | `ee5f65833f310dc4852785fdd31905b3ac15cf8887c968cd04b993645b56fbde` |

**Status carried by this baseline:**
- Issue 1 (joint enforcement): **specification closed · technically OPEN** — resolves only on T-1a…T-1d evidence (v5 §1.4).
- Issue 2 (transaction confirmation): **specification closed · technically OPEN** — resolves only on S-1…S-4 evidence (v5 §2.6).
- Issue 3 (offline policy): **CLOSED** — frozen configuration 48 h / 5 / ₹500 / ₹2,000 (v5 §3); alternatives removed from normative text or labelled out of scope.
- v4 §6 freeze checklist (evaluation freeze: thresholds/models/held-out set) is a **separate, later freeze** that must occur before headline evaluations; this record freezes the *specification*, not the evaluation parameters.

**Change rule:** editing any baselined file breaks its hash and constitutes a baseline change — record a new freeze (Baseline 1.1, …) here with the reason, and re-open any specification-closed status the change touches.
