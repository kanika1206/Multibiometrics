# Prototype Architecture — Bank Multimodal Biometric Product (with Deepfake Defence)
> **⚠️ v2 update (25 Oct 2026, after external review):** The protocol-level design in this document is superseded by **`protocol-spec-v2.md`**, which is now the governing document. Key v2 changes: (1) signing keys are *platform-gated per use* (a modified app faking PASS verdicts cannot silently obtain signatures); (2) the single 7-day offline challenge pack is split into a 7-day *local-access* credential and a strict *financial* pack (48 h, max 5 authorizations, RBI-aligned ₹ caps), with the **bank's server ledger — not the phone's counter — as the authority** against rollback/duplicates; (3) authentication, authorization and execution are separate stages with an audited state machine — a valid signature never by itself executes a transaction; (4) the attack lab is an *evaluation matrix* with per-layer attribution and a held-out attack set, not a demo where every attack fails; (5) build order is protocol-first (Phases 1–4 in the spec), and success is defined by the spec's Claims–Evidence Matrix. Sections below remain valid as the component inventory and demo outline; where they conflict with the spec, the spec wins.
**Purpose:** The architecture to actually *build* as a prototype/demo for the bank-specific product defined in `product-features-bank.md`. It reuses the submitted paper's stack and models wherever possible, and adds the offline, scalable and deepfake layers as separate, testable modules.
**Prototype scope decision (read first):** Build the **customer phone flow + bank backend + attack lab**. Simulate the bank's core banking system with a mock API (fake accounts/balances/transfers). Do NOT integrate a real bank, real money, or real KYC/Aadhaar in the prototype.

---

## 1. System diagram

```mermaid
flowchart TB
    subgraph PHONE["Customer phone — banking app (all biometrics happen here)"]
        UI["Capture UI<br/>live quality guidance"]
        CAP["Secure Capture Module<br/>• virtual-cam / emulator detection<br/>• session frame signing<br/>• device attestation token"]
        subgraph PIPE["On-device inference — persistent model service (ONNX)"]
            FACE["Face embedding<br/>MobileFaceNet-class, 512-d"]
            VOICE["Speaker embedding<br/>ECAPA-TDNN ONNX, 192-d"]
            STT["Challenge STT<br/>digit-grammar, offline"]
            FPAD["Face PAD / anti-spoof"]
            VPAD["Voice anti-spoof (deepfake voice)<br/>AASIST-class"]
            LIP["Lip-sync / AV binding"]
        end
        RISK1["On-device risk fusion<br/>identity = AND · security signals = risk score"]
        VAULT["On-device vault (SQLite/SQLCipher)<br/>cancelable template ~3 KB, AES-256-GCM<br/>key wrapped by Android Keystore / Secure Enclave"]
        KEY["Device private key<br/>secure hardware — never leaves phone"]
        UI --> CAP --> PIPE --> RISK1
        VAULT <--> PIPE
        RISK1 -->|all identity factors pass + risk acceptable| KEY
    end

    subgraph BANK["Bank backend — stateless services (Docker, load-balanced)"]
        CHAL["Challenge Service (Redis, 5-min TTL, single-use, CSPRNG)"]
        VERIFY["Verification Service<br/>signature + challenge + revocation check"]
        RISK2["Risk Engine (rules)<br/>device / location / amount / velocity → allow · step-up · deny"]
        ENROL["Enrolment & Device Service<br/>public-key registration, revoke, re-enrol"]
        AUDIT["Audit Log (append-only, async via queue)"]
        PUBDB[("Account / Public-Key Store<br/>MongoDB, sharded by hash(user_id)<br/>~200 B per customer — NO biometrics")]
    end

    subgraph CONSOLE["Bank console (web)"]
        OPS["Fraud & attempts dashboard"]
        ADMIN["Customer / device management<br/>policy console (thresholds, limits, step-up rules)"]
    end

    subgraph MOCK["Prototype-only simulations"]
        CORE["Mock Core Banking API<br/>accounts, balances, transfers"]
        LAB["⚔️ Attack Lab<br/>replay · TTS voice clone · face-swap video<br/>virtual-camera injection · mismatched AV pair"]
    end

    KEY -->|"signs challenge (login) or<br/>challenge‖amount‖payee (payment)"| VERIFY
    CHAL -->|"fresh challenge"| PHONE
    VERIFY --> RISK2 --> CORE
    PHONE -.->|"enrol: public key only"| ENROL
    VERIFY --> AUDIT
    ENROL --> PUBDB
    VERIFY --> PUBDB
    AUDIT --> OPS
    ADMIN --> ENROL
    LAB -.->|"attacks the capture pipeline"| CAP
```

## 2. Component-by-component (what to build, with what, and what's reused)

| Component | Build with | Reuse from submitted system? |
|---|---|---|
| Banking app UI | Existing React UI, wrapped for mobile (or React Native port if time allows — for prototype, a mobile-web/PWA build is acceptable and must be labelled as such) | ✅ UI flows (enrol, login, challenge display) |
| Capture + quality guidance | Camera/mic APIs; face-size & pose checks from the paper's enrolment quality gate, now live during capture | ✅ quality-gate logic |
| Face embedding | ONNX Runtime, current face model first; MobileFaceNet-class (~13 MB) if phone latency demands | ✅ model + τf = 0.35 start point |
| Speaker embedding | ECAPA-TDNN exported SpeechBrain/PyTorch → ONNX (~20 MB); parity gate: ONNX vs PyTorch embedding cosine > 0.99 | ✅ model + τa = 0.30 start point |
| Challenge STT | Vosk small + digit-only grammar (offline), whisper.cpp tiny as measured fallback | ❌ replaces external STT |
| Face PAD | MiniFASNet/Silent-Face-class ONNX, runs on already-extracted face crops | ❌ new |
| Voice anti-spoof | AASIST-class model, ONNX, runs on the same 16 kHz audio | ❌ new |
| Lip-sync check | Lip-focused AV-consistency model (SyncNet-class minimum; modern lip-sync model preferred — vanilla SyncNet is weak, ~66–80% in hard scenarios) | ❌ new (the novelty) |
| Model service | One persistent on-device process loading all models at app start; warm inference only — this + streaming (process *during* recording) is the latency fix | ♻️ replaces per-request model loading |
| Template vault | SQLCipher/SQLite; slim template = mean face (512-d) + speaker (192-d) binary ≈2.8 KB; **cancelable transform** (per-user random projection) before AES-256-GCM; key wrapped by OS keystore | ♻️ crypto pattern from paper, new format |
| Device key & signing | Platform WebAuthn/passkey where available, else app keystore key (ECDSA P-256). Private key in secure hardware; signs challenge / transaction payload | ❌ new |
| Secure capture | (a) attestation: Play Integrity / App Attest token fetched per session; (b) virtual-camera/emulator heuristics; (c) root/jailbreak signals; (d) session signing: HMAC over capture metadata + frame hashes with a per-session key, verified server-side | ❌ new |
| Challenge service | Node/Express + Redis; CSPRNG 6-digit (or action) challenge, 5-min TTL, single-use, consumed on first verify attempt; rate limits per account/IP/device | ♻️ paper's challenge lifecycle, fixed RNG + throttling added |
| Verification service | Node/Express, stateless; verifies signature, challenge freshness, credential expiry/revocation; identical generic failure to client | ♻️ paper's failure-disclosure rule |
| Risk engine | Simple rules engine (JSON/YAML policy file for prototype): signals = PAD scores, lip-sync score, attestation result, device age, amount, velocity counters (Redis) → allow / step-up (OTP/PIN/action challenge) / deny | ❌ new |
| Enrolment/device service | Registers public key + device metadata after identity binding (prototype binding = existing mock-account login + mock OTP); revoke, re-enrol, credential expiry 30–90 days with silent renewal | ♻️ paper's lifecycle (enrol / re-enrol-after-auth / delete), moved to device model |
| Audit | Async queue → append-only store (Mongo collection with no update path, or a log file chain for prototype); every event carries model versions + risk signals | ♻️ paper's server-side factor logging, extended |
| Bank console | React admin: attempts list w/ per-factor + risk detail, customer/device search, revoke button, policy editor (prototype: edit the risk policy file through a form) | ❌ new (simple) |
| Mock core banking | Tiny REST service: 10–20 fake customers, balances, transfer endpoint that *requires* a valid verification token for amounts above a threshold | ❌ prototype-only |
| Attack lab | Separate scripts/tools, NOT in the customer app: (1) replay — play recorded login video/audio; (2) clone — TTS/voice-conversion from ~30 s of target audio speaking the *fresh* challenge; (3) face-swap video of the target speaking digits; (4) injection — OBS virtual camera feeding (1)/(3) into the app/emulator; (5) mismatch — victim face video + cloned voice track combined. Dashboard records which layer caught each attack | ❌ new — the demo's centrepiece |

## 3. The three flows

### Enrolment (once, ~60 s)
1. Customer logs into mock bank the old way (password + mock OTP) — identity binding.
2. App checks device integrity/attestation → generates device key pair in secure hardware → public key registered with Enrolment Service.
3. Customer records **3 short clips** speaking shown phrases (quality guidance live). On-device: embeddings extracted, quality-weighted, averaged → cancelable transform → encrypted → stored in on-device vault. Raw clips deleted (paper's rule).
4. Server records: public key, device metadata, enrolment timestamp, model versions. **No biometric data crosses the network.**

### Login (≈21–23 s target, ~20 s of it the customer speaking)
1. App requests challenge → Challenge Service issues CSPRNG challenge (Redis, 5-min, single-use).
2. Capture starts; secure-capture checks run (attestation, virtual-cam, root). Processing **streams**: face frames are embedded and PAD-checked while the customer speaks; audio is transcribed (digit STT) and embedded incrementally.
3. On-device decisions: face ✓/✗, voice ✓/✗, challenge ✓/✗ (**AND**), PAD + lip-sync + integrity signals → **risk score**.
4. If identity passes and risk is acceptable → device key signs the challenge → Verification Service checks signature + freshness + revocation → Risk Engine (amount = 0 for login) → session issued. Grey-zone risk → step-up (PIN/OTP) before signing. Clear spoof signals → deny + audit (generic message to the customer).
5. Audit event written async. Raw media already gone; only the decision + signals are logged.

### Payment approval (the bank-specific flow)
1. Customer initiates a transfer in the mock app → app requests a *transaction* challenge.
2. Same biometric flow, but the device signs **(challenge ‖ amount ‖ payee ‖ timestamp)** — the approval is cryptographically bound to that one transaction (dynamic linking).
3. Verification Service + Risk Engine check amount-based policy (e.g. > ₹25,000 → mandatory step-up; limits are policy-file values in the prototype) → Mock Core Banking executes only with a valid, unexpired verification token.

### Offline behaviour (explicit, demoable)
- Airplane mode: enrolment viewing, biometric self-check and on-device verification all run; login *proof* (signature) is generated on-device and the bank step completes when connectivity returns. For the branch-kiosk variant, the terminal verifies fully offline against its branch-sharded gallery and syncs audit + revocations later.
- Demo script line: *"The biometric decision never needs the network. The bank does — and that's the correct separation."*

## 4. Deepfake defence — layer map (which layer stops which attack)
| Attack | Fresh challenge | Face PAD | Voice PAD | Lip-sync | Secure capture / attestation | Risk engine |
|---|---|---|---|---|---|---|
| Old recorded login replayed | ✅ (wrong digits) | ✅ screen artefacts | ✅ replay cues | ◐ | — | ◐ velocity |
| Photo / printed image | ✅ (can't speak) | ✅ primary | ✅ (no real voice) | ✅ (no lip motion) | — | — |
| Cloned voice speaking fresh challenge (real attacker on camera) | ❌ (it *is* fresh) | — (real face, wrong person → face match fails) | ✅ primary | ◐ (attacker's lips match — it's really speaking) | — | ◐ |
| Face-swap deepfake + cloned voice, presented to camera | ❌ if rendered live | ◐ (best current PAD) | ✅ | ✅ primary (AV mismatch artefacts) | — | ◐ step-up |
| Same deepfake **injected via virtual camera** | ❌ if rendered live | ◐ (PAD sees clean frames) | ✅ | ✅ | ✅ **primary — this is why capture integrity exists** | ◐ |
| Real-time interactive deepfake (live puppet) | ❌ | ◐ | ◐ | ◐ | ◐ | ✅ primary defence = step-up / limits / human review — *state this honestly* |
✅ primary defence · ◐ partial/supporting · ❌ does not stop it · — not relevant
**Takeaway for the prof/pitch:** no single layer stops everything; the *combination* is the product. The last row is deliberately honest — claiming to "solve" real-time deepfakes would be the fastest way to lose a bank's security team.

## 5. Prototype build order (mirrors Build Plan B, demo-first)
1. **Weeks 1–2:** On-device pipeline package (face + ECAPA-ONNX + digit STT + persistent model service) running in the app shell; enrol + login offline in airplane mode.
2. **Weeks 3–4:** Vault (slim cancelable template + keystore), device key + signing, Challenge + Verification services, mock core banking → full login + payment-approval flow.
3. **Weeks 5–6:** Deepfake layer: face PAD + voice PAD + lip-sync as risk signals; risk engine with the 3-outcome decision; step-up (PIN/mock OTP).
4. **Week 7:** Secure capture basics (attestation token, virtual-cam/emulator detection, session signing) + throttling/lockout.
5. **Week 8:** Bank console (attempts + risk dashboard, revoke, policy edit) + audit export.
6. **Weeks 9–10:** Attack lab (5 attacks) + results dashboard; load test (staged 10k/100k synthetic users against the stateless backend); final demo script + measurements for the v2 paper (Scenario C table, measured this time).

## 6. Demo script (10 minutes, for prof / bank)
1. Enrol a volunteer live (60 s) → show the server DB: only a public key, no biometrics.
2. Login + approve a ₹10,000 transfer with face+voice (show amount-bound approval screen).
3. Try to approve ₹10,000 to a *different* payee with the same approval → rejected (dynamic linking).
4. Airplane mode → biometric check still runs offline.
5. Attack lab, live: replay last week's recording → killed by challenge. Cloned voice → killed by voice PAD. Face-swap via virtual camera → killed by capture integrity + lip-sync. Show each result on the console with the layer that caught it.
6. Console: revoke the phone → next login denied within the credential window; show audit trail.
7. Close with the numbers table: v1 spoof acceptance 72–76% vs prototype's measured attack-lab results; 147 KB server templates vs ~200 B public keys; 1M-user load-test result.

---

## 7. Offline mode design (added on request — offline is a headline capability)
### 7.1 The design problem, solved explicitly
In the online flow the *bank* issues the fresh challenge, and freshness is what stops replay. Fully offline there is no bank in the loop — so who issues the challenge, and why should anyone trust the result later? The prototype uses this design:

**Signed Challenge Pack (the key mechanism):**
- Whenever the device is online, the Challenge Service issues a **pack of N=20 future challenges**, each individually signed by the bank (challenge value + pack id + sequence no. + expiry, e.g. 7 days), stored in the device's secure storage.
- Offline, the app consumes pack challenges **in sequence, each exactly once** (monotonic counter in secure storage; consumed entries are marked and cannot be re-presented). The spoken-challenge freshness argument survives: a recording made before the pack was issued contains the wrong digits, and a recording of pack challenge #k cannot be reused because #k is burned after one presentation.
- When the device later syncs, it presents the signed approvals it produced; the bank verifies *its own signatures* on the consumed challenges + the device signature + the counter sequence (a gap in the sequence = tampered/lost records → flag, don't silently accept).
- Pack runs out or expires → offline approvals stop (local unlock with device PIN still possible), online top-up of the pack at next connection. This expiry is the offline revocation window, and it is *quantified* (≤7 days in the prototype config) rather than hand-waved.

**What is signed offline:** approval payload = (pack-challenge-id ‖ amount ‖ payee ‖ device counter ‖ timestamp) signed by the device key — the same dynamic-linking payload as online, so an offline approval slots into the online verification path unchanged at sync time.

### 7.2 Offline components to build (delta on top of §2)
| Component | Build notes |
|---|---|
| Challenge Pack Manager (on-device) | Stores signed pack in secure storage (Keystore-backed), enforces sequential single-use consumption, tracks expiry; requests a new pack opportunistically on any online session |
| Challenge Pack Issuer (server) | Endpoint on the Challenge Service: issues signed packs to authenticated, non-revoked devices; per-device pack ledger (issued / reported-consumed ranges) in Redis + account store |
| Offline Queue (on-device) | Tamper-evident append-only queue (each record chained: hash of previous record included in the signed payload) holding approvals + offline payments until sync |
| Sync Engine (on-device + server) | Priority-ordered delta sync per product-features §7.4; idempotent submission (device counter + challenge id as dedupe keys) so a retried sync never double-executes a payment |
| Offline queue (prototype: mock) | Queued offline authorization requests under the **frozen configuration (v5 §3): ₹500/transaction, ₹2,000 cumulative, max 5 per 48-hour pack**; server ledger authoritative at sync; no stored-balance pocket (deferred, v3) |
| Kiosk Offline Mode | Branch terminal holds its sharded gallery + revocation deltas locally; verifies 1:1 fully offline; syncs audit/revocations when the branch link is up. Terminal's own credential expiry bounds how long a stale terminal can keep verifying |

### 7.3 Offline test protocol (acceptance tests for the prototype)
1. **Airplane-mode full run:** enrolment pack fetched online → airplane mode ON → 5 logins + 2 payment approvals + 1 offline-pocket payment, all succeed on-device; network monitor shows zero attempted external calls during offline operations (excluding OS noise, documented).
2. **Replay-against-offline:** record an offline login; try to re-present the same recording offline → must fail (challenge consumed + sequence advanced). Then try it *after* sync → must also fail at the bank (challenge id already reported consumed).
3. **Tamper test:** delete or edit one queued approval on a rooted/jailbroken test device (or via storage manipulation) → sync must flag the hash-chain/counter gap and freeze the pocket, not execute the edited record.
4. **Expiry test:** set pack expiry to 1 minute (test config) → after expiry, offline approvals refuse with a clear message; local PIN unlock still works.
5. **Sync chaos test:** kill connectivity mid-sync 3 times → no duplicate payment execution (idempotency keys), no lost approvals.
6. **Revocation-window test:** revoke the device on the console while it is offline → it keeps working locally until pack expiry (measure and *report* the window — this number goes in the paper, honestly).

### 7.4 Where offline sits in the demo script (update to §6)
Insert after step 3: **"Now airplane mode."** Do a live login + a ₹400 offline-pocket payment with radios off, show the queued signed approval, turn connectivity back on and watch it sync and settle on the console — then show the revocation-window number from test 7.3.6 on the closing slide. Offline stops being a bullet point and becomes a witnessed event.
