# Attack-Lab Matrix — DRAFT (does not freeze anything)

**Status:** Draft working document, prepared 2026-10-31 from Specification Baseline 1.0
and experimental-plan-v4. It introduces no new normative content: where this draft
and a frozen file differ, the frozen file wins. Nothing here counts as a freeze —
the evaluation freeze (thresholds, model manifests, sealed held-out set) must still
be completed first, using `evaluation-freeze-starter.md`, before any headline run.

**What this matrix is for:** turning the deepfake / presentation-attack layers from
"should work" into measured evidence, with per-layer attribution — exactly what the
v3 review required ("a measured evaluation matrix, not a guaranteed-fail demo").

## Rules carried over from experimental-plan-v4 (not re-decided here)

1. **Outcome taxonomy (§A), one outcome per trial, assigned by rule from the
   per-layer log — never by impression.** Every attack class reports four rates
   that sum to 100%: Accepted · Detected-and-denied (named control on the causal
   path) · Stepped-up (detected) · Stepped-up (risk-managed) — plus the
   inconclusive count. **No combined "blocked rate" may appear anywhere.**
   Headline metric = attack acceptance rate; detection and step-up rates are
   co-headlines, never footnotes.
2. **A denial by a control that was not the intended subject of the trial is
   credited to the control that fired, and flagged** so intended-control rates can
   also be reported both ways. No silent cross-crediting.
3. **Inconclusive trials** use only the pre-registered reason list (§A.2), tagged
   during the session, never retroactively. Headline rates are published twice:
   excluding inconclusive (primary) and worst-case (inconclusive attack trials
   counted as Accepted, genuine as Denied). If the two tell different stories
   about a claim, the claim is reported as not established.
4. **Scale:** ≥300 attempts per headline attack class, every rate with a
   Wilson / Clopper–Pearson 95% CI. A 0/30 result must be written as
   "0/30, 95% upper bound 9.5%" — never as "0%".
5. **Paired comparison:** all configurations B0–B5 run over the *identical*
   recorded corpus, so comparisons are paired on the same samples.
   Live-only properties (injection, capture integrity, coherent real-time
   impersonation) are labelled live/paired accordingly, not mixed into corpus rows.
6. **Correlated failure must be measured, not assumed away:** deepfake layers may
   fail together. Report joint attack acceptance *and* conditional rates (see §4).

## §1. Configurations under test (from v4 §B)

| Config | Identity (face ∧ voice ∧ 5-digit challenge, always) | Face PAD | Voice PAD | Lip-sync | Capture integrity | Purpose |
|---|---|---|---|---|---|---|
| B0 | ✓ | – | – | – | – | Identity-only = submitted v1 |
| B1 | ✓ | ✓ | – | – | – | Face PAD alone |
| B2 | ✓ | – | ✓ | – | – | Voice PAD alone |
| B3 | ✓ | – | – | ✓ | – | Lip-sync alone |
| B4 | ✓ | ✓ | ✓ | – | – | PAD pair |
| B5 | ✓ | ✓ | ✓ | ✓ | ✓ | Full system |
| B5−F, B5−V, B5−L, B5−C | ✓ | leave-one-out ×4 | | | | Ablations, derived from the same runs by verdict masking where the layer is offline-scorable |

Pre-registered P2 bar (v4 §B, frozen numbers): on the **held-out** set, B5 attack
acceptance ≥20 points below B0 *and* ≥5 points below the best single-layer config
(B1–B3), paired 95% CIs excluding 0, within the cost budget FRR(B5) − FRR(B0)
≤ +3 points, p95 latency increase ≤ +2.0 s, footprint ≤ 250 MB. Failing the cost
budget with the security bars passing = the pre-agreed wording: "P2 supported as a
security result, not yet as a product improvement."

## §2. Attack-class matrix (fill in generation tool + version before freezing)

Each row is one headline class. "Corpus / live" decides whether the row can be
paired across configs. Leave tool/version blank until the freeze — do not guess.

| # | Attack class | What the attacker presents | Corpus or live | Layers it is meant to test | Intended denying control(s) | Planned n (≥300 headline) |
|---|---|---|---|---|---|---|
| A1 | Face presentation — photo | Still image of the enrolled face | Corpus | Face PAD | Face PAD | |
| A2 | Face presentation — video replay | Recorded video of the enrolled face, incl. speaking | Corpus | Face PAD, lip-sync | Face PAD / lip-sync | |
| A3 | Face presentation — mask / 3D artefact | Physical artefact of the enrolled face | Live | Face PAD, capture integrity | Face PAD | |
| A4 | Voice replay | Recorded voice of the enrolled speaker, incl. spoken digits | Corpus | Voice PAD, challenge | Voice PAD / challenge | |
| A5 | Voice synthesis / cloning | Synthesised voice speaking the fresh 5-digit challenge | Corpus | Voice PAD, challenge | Voice PAD / challenge | |
| A6 | Face swap / deepfake video (offline-generated) | Swapped-face video speaking the challenge | Corpus | Face PAD, lip-sync | Face PAD / lip-sync | |
| A7 | **Coherent real-time impersonation (mandatory class, v3)** | Live deepfake face + cloned voice, responding to the fresh challenge in real time | Live | All layers jointly | Any / joint — this is the class that tests correlated failure | |
| A8 | Injection — virtual camera / injected frames | Frames fed to the pipeline bypassing the real camera | Live | Capture integrity, attestation path | Capture integrity | |
| A9 | Injection — pre-recorded stream | Pre-recorded audio-video stream presented as live capture | Live | Capture integrity, lip-sync, challenge | Capture integrity / lip-sync | |
| A10 | Genuine-user control (not an attack) | Enrolled user, live, fresh challenge | Corpus + live | Cost measurement | — | Report first-attempt success, eventual success, FRR |

Cross-reference, not duplication: the spec-closure boundary tests T-1a…T-1d
(modified app / rooted device / no signature without fresh platform auth / network
tampering) and consent-substitution tests S-1…S-4 belong to the protocol-closure
evidence, not to this matrix — run them separately and cite them alongside, so a
matrix pass is never read as a protocol pass.

## §3. Leave-one-layer-out ablation (from the same runs)

For each attack class, report B5 alongside B5−F, B5−V, B5−L, B5−C (verdict
masking where offline-scorable; live re-run where masking is not valid, and say
which). The ablation question per row: *how much does attack acceptance rise when
exactly this layer is removed, with everything else held fixed?* A layer whose
removal changes nothing on any class is a finding, not an embarrassment — report
it in the trade-off table, including any row where the full system looks bad.

## §4. Joint and correlated-failure analysis (v3 requirement)

Single-layer rates alone cannot support the layered claim. For the full system
(B5) and for A7 in particular, also report:

- Joint attack acceptance: accepted by **all** layers together, per class.
- Conditional acceptance: P(accepted | layer X failed) for each layer X — i.e.
  when one layer misses, how often do the others still catch it?
- Conditional correlation: for each pair of layers, the rate at which both fail
  on the same attempt, vs the rate independence would predict.
- Per-layer attribution table: for every denied attack trial, which named control
  was on the causal path (v4 §A rule 4 — cross-credited denials flagged, not hidden).

## §5. Per-configuration reporting row (one row per config, no exceptions)

Copy this row for B0–B5 and each ablation, per attack class and overall:

- Attack: Accepted / Detected-and-denied / Stepped-up (detected) /
  Stepped-up (risk-managed), each with 95% CI + inconclusive count.
- Genuine: first-attempt success, eventual success, FRR (with inconclusive count
  beside it).
- Cost: p50/p95 latency per attempt on the reference device, total model
  footprint (MB), peak RAM, mean CPU-seconds per attempt (corpus runs).
- Verdict on the P2 bar for that row: pass / fail / "security result, not yet a
  product improvement" — using the pre-agreed wording only.

## §6. Run order (suggested, not frozen)

1. Complete the evaluation freeze first (thresholds, model manifests, sealed
   held-out inventory by hash, reference device, analysis-code commit).
2. Development corpus: run the full matrix, tune only on development data.
3. Held-out set: run once, sealed, paired across configs. Tuning after seeing
   held-out results converts that set into development data and must be declared.
4. Live-only classes (A3, A7, A8, A9) last, labelled live, with operator-tagged
   inconclusive reasons recorded during each session.
5. Publish primary rates and worst-case sensitivity side by side; any claim
   where they disagree is reported as not established.

## Open blanks (deliberately not filled in here)

PAD and lip-sync thresholds · model names/versions/hashes for B0–B5 ·
generation tools and versions per attack class · reference device spec ·
held-out inventory hashes · analysis-code commit. All come from Kanika's actual
code and data at freeze time — none are guessed in this draft.
