# Build Plan A — OFFLINE Version
**Project:** Secure User Authentication Using Multimodal Biometrics (Draft 7) → fully offline
**Goal in one line:** Face ∧ voice ∧ spoken challenge verified 100% on one device, with **zero network calls** during enrolment and login.
**Not this plan:** scaling to lakhs of users, bank/server integration, 1:N search — that is Build Plan B (Scalable).
**Starting point (already built):** React client + Express/Node 22 server + MongoDB + Python 3.12 pipeline — face embeddings via ONNX Runtime (512-d, τf = 0.35), speaker embeddings via SpeechBrain ECAPA-TDNN in PyTorch (192-d, 16 kHz, τa = 0.30), external STT for the 5-digit challenge, AES-256-GCM per-user encrypted templates with a separate server key vault, strict AND decision (Eq. 6).
**Timeline estimate:** 5–6 weeks solo, 3–4 weeks for a 2-person team. Estimates, not commitments — Phase 2 is the long pole.
**Target device for acceptance:** the paper's own low-end machine class — i5 / 8 GB RAM laptop, and one mid-range Android phone if mobile is in scope. Decide laptop-first (recommended) vs phone-first in Phase 0; do not build both in v1.

---

## Architecture after this plan
```
[Camera + Mic] → [Local app: capture UI]
                      │
                      ├─► Face branch: face detect/align → ONNX face model (resident) → 512-d embedding → cosine vs enrolled
                      ├─► Voice branch: 16 kHz mono → ECAPA-TDNN ONNX (resident) → 192-d embedding → cosine vs enrolled
                      └─► Challenge branch: local CSPRNG 5-digit challenge → digit-grammar offline STT → exact match
                                          │
                              AND decision (all three must pass)
                                          │
              [Local encrypted store: SQLCipher/SQLite — templates AES-256-GCM,
               per-user key wrapped by OS keystore (Windows DPAPI/TPM, Android Keystore, macOS Keychain)]
```
No Express server, no MongoDB, no external STT, no network socket opened at runtime in v1.

---

## Phase 0 — Decisions & freeze (2–3 days)
- [ ] Pick v1 target: **desktop/laptop app first** (recommended — same OS/hardware class as the existing prototype, no app-store or NPU-delegate surprises) packaged with the existing React UI in a desktop shell (e.g. Tauri/Electron) *or* a localhost-only local service with the browser UI. Record the decision; phone port becomes a later phase, not parallel work.
- [ ] Freeze what does NOT change: thresholds (τf = 0.35, τa = 0.30), 12-frame sampling, median face score, AND rule, challenge format (5 digits, 5-min TTL, single-use), enrolment quality gate (≥6 usable frames, face ≥80×80 px).
- [ ] Write the revised threat-model paragraph for the paper *now* (verifier = device; assume device not rooted; challenge generated locally) so the build and the claims stay in sync.
- **Exit gate:** one-page decision note signed off (by professor, if this is for the paper).

## Phase 1 — Extract the pipeline from the server (Week 1)
- [ ] Carve the Python biometric pipeline out of the Express request flow into a standalone **local inference service** (same Python 3.12 code, called by the local app, not by a network server): inputs = one recording file, outputs = face embedding set, speaker embedding, transcript.
- [ ] Add a **persistent model manager**: load face + speaker models once at app start, keep them resident, expose a health/ready state. This directly attacks Draft 7's dominant cost — extraction was 6.5 s (live) to 12.4 s (controlled) with model loading a major contributor; matching was only ~150–200 ms.
- [ ] Replace MongoDB reads/writes in the pipeline with a repository interface (`get_template(user_id)`, `put_template(...)`, `delete_user(...)`) so Phase 3 can swap the backend without touching biometric code.
- [ ] Keep server code untouched on a branch — offline is a fork of the deployment, not a rewrite of the algorithms.
- **Exit gate:** from the command line, enrol + verify a user end-to-end locally with the server and MongoDB switched off (network still on at this stage is fine).

## Phase 2 — Offline models (Weeks 2–3) ← hardest phase
- [ ] **Face:** keep the current ONNX face model first; benchmark on the target laptop. Only if too slow/large, swap to a MobileFaceNet-class ONNX model (~13 MB vs ~166 MB for ResNet-50 class) and re-validate (see Phase 5) — do not change model and thresholds in the same step.
- [ ] **Voice:** export ECAPA-TDNN from SpeechBrain/PyTorch to **ONNX** (~20 MB class), 16 kHz mono in, 192-d out. Verify embedding parity: same audio through PyTorch and ONNX versions must give cosine similarity ≈ 1.0 (target > 0.99) before any other testing.
- [ ] **STT replacement:** integrate an offline recogniser with a **digit-only grammar** (Vosk small model with a restricted [0–9] grammar, or whisper.cpp tiny as fallback). The vocabulary is only ten words — build a small digit test set (≥10 speakers × 20 random 5-digit strings, varied noise) and measure digit-string accuracy; this replaces the external-STT failure modes seen in Draft 7's logs (CAPTCHA_MISMATCH, SPEECH_NOT_RECOGNIZED).
- [ ] Quantise (INT8) face/voice models only if Phase 2 benchmarks miss the latency budget, and re-run parity checks after quantisation.
- **Latency budget (set now, measure at exit):** warm verification (models already loaded) server-equivalent processing ≤ 3 s on the target laptop, cold start ≤ 10 s. Label as targets until measured.
- **Exit gate:** full enrol + login runs with **Wi-Fi off / airplane mode**, warm-login time measured and logged.

## Phase 3 — Local storage, keys & challenge (Week 3–4)
- [ ] Local DB: SQLite/SQLCipher with the paper's data model reduced to one device — accounts, encrypted templates, attempt log. No cross-user template comparison (preserve Draft 7's per-user key isolation and no-biometric-uniqueness stance).
- [ ] Keys: per-user random 256-bit template key, AES-256-GCM encrypt the template exactly as now, but wrap the per-user key with an **OS-backed key** (DPAPI/TPM on Windows, Keychain on macOS, Keystore on Android) instead of the server vault's master key. Plaintext keys exist only in memory during an attempt, then cleared (same rule as Draft 7 §3.7).
- [ ] Challenge: generate with the OS **CSPRNG** (never `Math.random` — Draft 7's known weakness), keep the expected value only in local memory, 5-min expiry, consume on first use regardless of outcome, never write it to disk/logs in plaintext.
- [ ] Port the account lifecycle (§3.9) to local equivalents: enrol (purpose-bound, cannot overwrite), authenticated re-enrol (only after a successful 3-factor login, atomic template swap, new per-user key), delete account = delete account row + template + wrapped key + transient files. Operator recovery becomes a documented local admin procedure (delete + re-enrol) — state this limitation plainly.
- **Exit gate:** storage audit — grep the device: no raw recordings retained, no plaintext template/key/challenge anywhere on disk; tampered template or key → attempt rejected (as in Draft 7).

## Phase 4 — Packaging & offline-proofing (Week 4–5)
- [ ] Bundle everything into one installer/app: UI + local service + models + STT model. Total install size target < 300 MB (models ≈ 13–20 MB each + STT ≈ 40 MB + runtime).
- [ ] **Offline firewall test:** run the full test script with network disabled at OS level and with a network monitor running — acceptance requires zero attempted external connections during enrol, login, re-enrol, delete.
- [ ] Failure UX offline: identical generic failure message regardless of which factor failed (preserve Draft 7 behaviour), local-only attempt log with factor outcomes for debugging/research.
- [ ] Update/model-replacement procedure documented: models ship with app updates; template format version field added so a future model change can force re-enrolment instead of silently mismatching.
- **Exit gate:** a fresh machine (or VM) with no internet installs the app and completes enrol + 5 logins.

## Phase 5 — Evaluation (Week 5–6, can overlap Phase 4)
- [ ] **Accuracy parity:** re-run the CREMA-D face ∧ voice protocol with the offline (ONNX/quantised) models — compare FAR/FRR/EER against Draft 7's reported values (voice EER 3.15% main protocol; face∧voice FRR 6.13%, observed FAR 0/583,214). Any drift beyond the reported CIs must be explained or the model swap rolled back.
- [ ] **Digit-challenge accuracy:** report string-exact accuracy of the offline digit STT (Phase 2 test set) vs the external STT's behaviour in Draft 7 logs.
- [ ] **On-device performance table** for the paper: cold start, warm enrol time, warm login time (capture vs processing split), RAM during inference, install size, template size (~147 KB/user unchanged) — on the target laptop, N ≥ 20 attempts.
- [ ] **Offline robustness mini-study:** low light, fan/room noise, second device (one extra laptop/webcam) — explicitly labelled as preliminary, since Draft 7 has no cross-device evaluation.
- **Exit gate:** results tables drafted in the same format as Draft 7 Tables 3/6/7, ready to drop into the paper as a new section.

## Risks & mitigations
| Risk | Mitigation |
|---|---|
| ECAPA ONNX export mismatch quietly changes scores | Embedding-parity test (cosine > 0.99) as a Phase 2 gate, before any accuracy claims |
| Offline STT worse than cloud STT on digits | Digit-only grammar (10-word vocab) usually reverses this; keep whisper.cpp tiny as a measured fallback, pick by data |
| Low-end device too slow | Persistent models first, INT8 second, MobileFaceNet swap third — in that order, re-validating each time |
| Rooted/modified device bypasses the AND decision | Out of scope for v1; state it in the threat model. Do not claim server-grade assurance |
| No revocation / no central audit | Accepted for offline v1; short template expiry is a *design option to discuss with professor*, not silently added |

## Deliverables
1. Offline app (installer) + source branch
2. On-device performance + accuracy-parity results tables
3. Storage/key audit report (Phase 3 gate)
4. Paper material: revised threat-model paragraph + new "Offline Deployment" section draft

## What this plan deliberately does NOT do
- No user-base scaling work, no cloud/server scaling, no FIDO/passkey layer, no PAD/liveness, no 1:N identification. Those are Plan B (or future work), and mixing them in would double this plan's size.
