# Product Features — Bank Multimodal Biometric Authentication
**Working concept:** A bank app login + transaction-approval product where the customer's **face + voice + spoken challenge** are verified **on their own phone (offline-capable)**, the phone's secure hardware signs the bank's challenge, and the bank never stores biometric data. Built as the product version of the submitted research paper, extended per professor's direction: **offline + scalable + deepfake-resistant**.
**Users:** (1) Bank customers (retail app users), (2) Bank staff — fraud/ops team (admin console), (3) Branch staff (assisted enrolment/kiosk).
**Priority key:** **MVP** = prototype must have it to demo the idea · **V1** = first real pilot · **Later** = roadmap.

---

## 1. Core customer features
| # | Feature | Priority | Notes |
|---|---|---|---|
| 1.1 | **Passwordless bank login** — look at camera + speak the shown challenge → logged in. No password/OTP typing in the normal path | MVP | Face ∧ voice ∧ challenge, strict AND (from the paper) |
| 1.2 | **Transaction approval with your face+voice** — for a transfer, the app shows amount + payee, speaks/signs *that specific transaction* (dynamic linking), not a generic login | MVP | This is what makes it bank-grade vs a college login demo: approval for ₹500 to A cannot be replayed for ₹50,000 to B |
| 1.3 | **One-time enrolment in ~60 seconds** — 3 short recordings (multi-sample) while speaking shown phrases, bound to the existing account (existing login + OTP / KYC check at enrolment only) | MVP | Multi-sample is what buys back FRR (see performance projection: FRR 6.1% → ~3.5–4.5% projected) |
| 1.4 | **Works on the customer's own phone, mid-range included** — small models (~13 MB face, ~20 MB voice), warm login processing ≤ ~3 s target | MVP | Minimum device spec published; graceful fallback (1.7) for unsupported phones |
| 1.5 | **Offline biometric check** — face/voice/challenge verified on-device with no network; the *bank step* (signature verification) happens when connectivity is available. In-app "offline mode" also covers branch/field use (kiosk, rural banking correspondent) | MVP | Be precise in marketing: biometrics offline, banking online — a balance cannot load offline |
| 1.6 | **Retry & guidance UX** — "move to better light", "speak closer", live quality feedback (face size/pose, audio level) *before* capture, max 3 attempts then step-up | MVP | Draft 7's live logs failed mostly on capture/challenge, not matching — guidance attacks the real failure mode |
| 1.7 | **Fallbacks that don't defeat the product** — device PIN as step-down for a failed biometric (with lower transaction limits), OTP step-up for high-risk events, branch re-verification for lost phones | MVP (PIN), V1 (limits policy) | Fallback must be *weaker-but-limited*, never a full bypass |
| 1.8 | **Multi-device & new-phone flow** — enrol a second device, move to a new phone via re-proofing (old device approval or branch/KYC), instant deactivation of the old device | V1 | The #1 support scenario in real banking; design it before pilot, not after |
| 1.9 | **Accessibility** — voice-only path for visually impaired users, face-only + PIN path for speech-impaired users, large-text challenge, language options for the spoken challenge (English + Hindi for v1 India scope) | V1 | A bank cannot ship a login that excludes customers; also a regulatory expectation |
| 1.10 | **Customer control panel** — see enrolled devices, last login attempts, revoke a device, delete biometrics (erasure), download consent record | V1 | DPDP Act rights (access/erasure) made into product features, not legal afterthoughts |

## 2. Deepfake & anti-spoof features — the headline security layer
*Why this is a feature block, not a footnote: deepfake attacks on identity checks are industrialised — Group-IB documented 8,065 deepfake injection attempts against ONE financial institution's KYC flow in Jan–Aug 2025; voice cloning is now the most common GenAI fraud type reported by financial professionals; a deepfake attack on digital identity was recorded roughly every 5 minutes in 2024, and deepfakes were ~24% of fraudulent attempts against motion-based biometrics. A bank product sold in 2026 without a deepfake story is unsellable.*

| # | Feature | Priority | What it actually does |
|---|---|---|---|
| 2.1 | **Face presentation-attack detection (PAD)** — passive anti-spoof model (MiniFASNet/Silent-Face class, on-device) on every login: photo, screen replay, mask, printed image | MVP | Projected photo/replay acceptance → low single digits (model class ACER ≈2–3%); report in ISO/IEC 30107-3 terms (APCER/BPCER) |
| 2.2 | **Voice anti-spoof / deepfake-voice detection** — AASIST-class countermeasure on every login: TTS, voice conversion, cloned voice, replayed recording | MVP | Projected LA spoof acceptance 72% → ~1–3% (see projection doc). PA (loudspeaker replay) is weaker — projected ~4–8% — say so |
| 2.3 | **Lip-sync / audio-visual binding check** — verifies the mouth movements match the spoken challenge digits, so a real face video + a cloned-voice track (or vice versa) fails even if each passes alone | MVP | The product's differentiator — nobody in the paper's comparison set does this, and it's free (same video stream). Soft/risk gate, not a hard reject (see §3) |
| 2.4 | **Injection-attack defence — secure capture pipeline** ⭐ *most products miss this* | MVP (basic), V1 (full) | PAD checks what the camera *sees*; injection attacks bypass the camera entirely, feeding a deepfake stream through a **virtual camera / emulator / hooked app**. Defences: (a) virtual-camera & emulator detection, (b) device/app attestation (Play Integrity / App Attest) before capture, (c) rooted/jailbroken-device detection, (d) capture-session signing — the app signs frames/metadata at capture so a substituted stream fails verification. ISO 30107-3 PAD does **not** cover injection — this needs its own feature, and its own slide in the pitch |
| 2.5 | **Fresh, unpredictable challenge — upgraded** — CSPRNG challenge (fixing the paper's `Math.random`), 6 digits, single-use, 5-min expiry, plus a randomised *action* variant for high-risk approvals (turn head left/right on prompt — photometric/kinematic challenge an injected buffered stream struggles to answer in time) | MVP (digits), V1 (action variant) | Challenge stops pre-recorded attacks; the action variant specifically raises the cost of real-time deepfake rendering |
| 2.6 | **Real-time deepfake realism check** — signal-level analysis beyond PAD: illumination consistency, blink pattern, screen moiré/refresh artefacts on the face branch; spectral artefacts on the voice branch (largely inside 2.1/2.2 models — expose as one "deepfake risk score" to the risk engine, §3) | V1 | Honest limit, state it in the product doc: a *real-time, interactive* deepfake that renders the victim live IS the hardest case; the product's answer is layered (2.4 capture integrity + 2.5 timed actions + §3 risk/step-up), not a magic detector |
| 2.7 | **Attack lab / red-team mode (internal feature)** — a test harness that attacks the *own* product: replay attack, TTS clone (from 30 s of audio), face-swap video, virtual-camera injection (OBS virtual cam), mismatched AV pair — with a results dashboard | MVP (basic set), V1 (full) | For a bank demo/pilot this is gold: the bank's security team will run these anyway; shipping the lab yourself = credibility. Also generates the v2 paper's attack-evaluation table |
| 2.8 | **Model-update channel for detectors** — deepfake generators evolve monthly; PAD/anti-spoof models must be updatable via app/model update without re-enrolling users, with version reporting per login | V1 | A 2026 detector shipped frozen is a 2027 vulnerability. Include detector version in every audit record |

## 3. Risk engine & decision features (how the gates combine)
| # | Feature | Priority | Notes |
|---|---|---|---|
| 3.1 | **Risk-scored decision, not just pass/fail** — identity factors stay strict AND; security signals (face PAD, voice PAD, lip-sync, device integrity, injection checks) fuse into a **risk score** with 3 outcomes: *allow / retry-or-step-up / deny* | MVP | This is the Scenario-C design from the projection: it keeps projected FRR ~5–7% while spoof acceptance collapses — hard-AND-ing everything would push FRR to ~13% |
| 3.2 | **Risk-based step-up** — new device, unusual location/time, high amount, grey-zone risk score → add OTP/PIN or action challenge (2.5) | MVP (basic rules), V1 (full rules console) | Matches RBI's risk-based approach: extra checks beyond the 2FA minimum based on fraud-risk perception |
| 3.3 | **Attempt throttling & lockout** — max attempts per window, exponential backoff, lock + alert; velocity checks across accounts/devices for the ops team | MVP | Fixes a verified gap in the submitted system (no throttling existed) |
| 3.4 | **Transaction limits by assurance level** — e.g. biometric-only up to ₹X, + step-up above ₹X, branch-only above ₹Y (bank-configurable) | V1 | Lets the bank adopt gradually instead of all-or-nothing |

## 4. Scalability features (professor's second direction — as product capabilities)
| # | Feature | Priority | Notes |
|---|---|---|---|
| 4.1 | **Device-sharded verification** — biometric compute lives on customers' phones; adding a customer adds their compute. Bank server does one signature verification per login | MVP | The core scale claim: server cost per login drops from ~6.5 s of inference to a sub-ms signature check |
| 4.2 | **The bank stores NO biometrics** — only ~200-byte public keys per customer: 1M customers ≈ 0.2 GB, 100M ≈ 20 GB (vs ~147 GB / ~14.7 TB for server-side templates) | MVP | Simultaneously the scalability feature, the privacy feature, and the breach-impact feature — one line, three pitch points |
| 4.3 | **Stateless, horizontally scalable backend** — challenge + verification + revocation services scale by adding identical instances behind a load balancer; account store sharded by user-id hash | MVP (design), V1 (autoscaling config) | Load-test gates: 10k → 100k → 1M enrolled (Build Plan B) |
| 4.4 | **Slim, revocable templates** — ~3 KB cancelable templates on-device (vs 147 KB), re-issuable if a device is compromised (rotate the transform + key, no new face needed) | MVP | Cancelable transform also = the "template revoked" story auditors ask for |
| 4.5 | **Branch/kiosk mode** — shared terminal, claimed-ID first (card/phone), gallery sharded *by branch* (≤ ~1,000/terminal), FAISS shortlist only if 1:N fallback is truly needed | V1 | Bounded by design; FPIR grows ≈ N × FAR, so the product *refuses* national-scale 1:N — a feature, stated proudly |
| 4.6 | **Delta sync & short-lived credentials** — enrolments, revocations and model updates sync as small deltas; device credentials expire in 30–90 days and renew silently on login, so a lost phone dies by expiry even if never wiped | V1 | Makes revocation work in a distributed/offline fleet — the known weak point of offline systems |

## 5. Bank-side features (admin / fraud / compliance console)
| # | Feature | Priority | Notes |
|---|---|---|---|
| 5.1 | **Fraud & attempts dashboard** — logins, failures by factor (server-side only — customers never see which factor failed), PAD/deepfake risk distribution, injection-attempt flags, attack-lab results | MVP (basic logs view), V1 (dashboard) | Per-factor detail stays internal (as in the paper) to avoid giving attackers an oracle |
| 5.2 | **Customer/device management** — search customer, see devices & enrolment status, force revoke, force re-enrol, unlock after lockout | V1 | The ops team's daily tools |
| 5.3 | **Policy console** — thresholds, attempt limits, transaction limits by assurance level (3.4), step-up rules, challenge type — changeable without an app release | V1 | Banks will not accept hardcoded risk policy |
| 5.4 | **Audit trail** — append-only record of every enrolment, login, approval, revoke, policy change: who/when/device/model versions/result. Exportable for auditors | MVP (log), V1 (export) | Non-negotiable for a bank; cheap to build early, painful to retrofit |
| 5.5 | **Compliance pack (documentation feature)** — mapping doc: RBI Authentication Directions 2025 (2FA, dynamic factor, independent factors, risk-based checks), DPDP Act (consent, purpose, erasure), ISO 30107-3 PAD evaluation reports, data-flow diagram showing biometrics never leave the device | V1 | In Indian banking, this pack is often the actual gate to a pilot |
| 5.6 | **Assisted enrolment (branch)** — staff-supervised enrolment mode with stronger identity proofing for customers who can't self-enrol | V1 | Also the recovery path anchor (lost phone + failed self-recovery → branch) |

## 6. Non-functional requirements (the numbers the product is judged on)
- **Login time:** ≤ ~22 s end-to-end target (mostly the customer's speaking time; ≤ ~3 s processing after capture) — from ~27 s in v1 via persistent models + streaming processing
- **Accuracy targets (to be validated, Scenario C):** system FRR ~5–7%, voice LA spoof acceptance < 5%, PA < 10%, face PAD ACER ~2–3% class
- **Scale targets:** 1M enrolled users on the stateless backend (load-tested, staged), p95 server-added latency < 1 s
- **Availability:** biometric check works offline on-device; bank services degrade to OTP login if the biometric service is down (never lock customers out of their bank)
- **Privacy:** raw audio/video never leaves the phone and is never stored; only embeddings (cancelable, encrypted) exist, on the device only

## MVP in one sentence (for the demo/prototype)
Customer enrols once (3 recordings) → logs in and approves a payment with face+voice+challenge on their phone, offline-verified, device-signed → bank console shows the attempt, the risk score and the audit record → then the **attack lab** tries to beat it live (replay, cloned voice, face-swap, virtual-camera injection) and the deepfake layer's results are shown next to v1's 72–76% spoof acceptance. *That last contrast is the entire pitch.*

## Sources (web search, 25 Oct 2026)
- 8,065 deepfake injection attempts against one institution's KYC (Jan–Aug 2025); voice cloning = most common GenAI fraud (60%): https://medium.com/serenity-shield/they-didnt-hack-the-fingerprint-scanner-they-hacked-the-person-watching-it-a2f7cf78b13c
- Deepfake attack every ~5 minutes in 2024; deepfakes ≈24% of fraudulent motion-biometric attempts; injection attacks defined: https://www.infosecurity-magazine.com/news/deepfake-identity-attack-every/
- Injection defence requires device attestation, sensor binding, pipeline signing — beyond liveness/PAD alone: https://www.biometricupdate.com/202511/not-an-iphone-issue-the-broader-reality-of-deepfake-injection-techniques and https://www.daon.com/resource/what-the-media-gets-wrong-about-deepfakes-and-iphone-injection-attacks/
- ISO 30107-3 covers presentation attacks, not injection — separate controls needed: https://www.fluxforce.ai/blog/injection-attack-liveness-detection-presentation

---

## 7. Offline features — the third headline (added on request)
*Offline is not one feature, it is a mode the whole product must survive. The three headline capabilities of this product are: **deepfake-resistant · scalable · offline-capable.***

### 7.1 What works FULLY offline (no internet, no telecom signal)
| Feature | How |
|---|---|
| Face verification | On-device model, on-device template — never needed the network |
| Voice verification | On-device ECAPA-TDNN ONNX |
| Spoken challenge | Generated on-device by CSPRNG (prototype: pre-fetched signed challenge pack, see architecture §7 — the bank-grade way), transcribed by the offline digit-grammar STT |
| Deepfake layer | Face PAD, voice anti-spoof, lip-sync, virtual-camera/root checks — all on-device models, all offline |
| Login to the *app itself* (local unlock) | Full biometric decision on-device → app opens in offline mode (cached, read-only view of last-synced data, clearly badged "Offline — last updated …") |
| Branch kiosk / banking-correspondent authentication | Terminal verifies against its branch-sharded local gallery (≤ ~1,000 users), fully offline |
| Queued transaction approval | Customer biometrically approves a payment offline → the signed approval is stored in a tamper-evident offline queue on the device → auto-submitted when connectivity returns (within the approval's validity window) |

### 7.2 What does NOT work offline — stated honestly, designed around
| Limitation | Product answer |
|---|---|
| Balance / statement / any live bank data | Show last-synced snapshot with timestamp; never present stale data as live |
| Instant transfer settlement | Only *small-value offline payments* settle offline, within RBI's Offline Framework caps (see 7.3); larger transfers are queued approvals (7.1), executed online |
| Revocation taking effect on a lost phone | Short-lived device credentials (30–90 days, auto-renewed at online logins) + offline spending caps bound the exposure window |
| Fresh bank-issued challenge for a *remote* login | Remote login is online by definition; offline mode covers local unlock, kiosk, and queued/proximity payments |

### 7.3 Offline payments, aligned to RBI's framework (a concrete, citable feature)
RBI's *Framework for Facilitating Small Value Digital Payments in Offline Mode* prescribes an upper limit of **₹500 per offline transaction** and a **total limit of ₹2,000 per payment instrument** at any point in time, with enhanced UPI Lite limits of **₹1,000 per transaction / ₹5,000 total** (RBI amendment, Dec 2024). **Prototype scope (frozen, v5 §3): this project implements only the ₹500/₹2,000 configuration — 48-hour pack, max 5 authorizations. The UPI Lite enhanced limits above are external background only and are out of scope.** Product features built on this:
- **Offline wallet pocket:** a pre-funded, on-device sub-balance (bank-configurable, defaults aligned to the framework caps) usable for proximity/face-to-face payments with biometric approval and *no AFA required by the framework for these small offline transactions* — our biometrics exceed the minimum rather than being the minimum.
- **Consent-gated enablement:** offline payments are enabled only after the customer's specific consent (a framework requirement), from the control panel (feature 1.10).
- **Deferred alerts & receipts:** transaction alerts/receipts are delivered when connectivity returns (framework expects a time lag) — the app shows "pending sync" receipts meanwhile.
- **Online-only replenishment:** topping up the offline pocket happens only online, with full authentication (framework rule).
- **Double-spend protection:** monotonic on-device counters + signed transaction records in secure storage; the bank reconciles on sync and any counter gap freezes the pocket pending review.

### 7.4 Sync features (what happens when the internet comes back)
- **Auto-sync engine:** audit logs, queued approvals, offline payment records, and revocation/model updates exchange as small signed deltas, in priority order: (1) revocations & fraud flags down, (2) queued approvals & offline payments up, (3) audit logs up, (4) model/policy updates down.
- **Conflict rules, written down:** bank state wins for revocation/limits; device state wins for *what the customer approved* (a signed approval is evidence, never silently dropped — it is accepted, rejected-with-reason, or expired, and the customer is told which).
- **Freshness badges everywhere:** every screen that shows synced data shows its age; risk engine treats long-unsynced devices (> X days, policy) as higher risk and can require an online check before high-value approvals.

### 7.5 Offline as a selling point (use cases to name in the pitch)
Rural/semi-urban banking and banking correspondents with weak connectivity · branch operations during network outages (the branch keeps authenticating customers) · travel (flights, low-signal areas) for app unlock · disaster/outage resilience — the bank's authentication does not die with its data centre's network · privacy-sensitive users (biometrics that never travel are also biometrics that work with the radio off).

### Source for §7.3
RBI official amendment (4 Dec 2024) — offline framework caps ₹500/transaction, ₹2,000 total; UPI Lite enhanced to ₹1,000/transaction, ₹5,000 total: https://rbi.org.in/Scripts/NotificationUser.aspx?Id=12752&Mode=0
