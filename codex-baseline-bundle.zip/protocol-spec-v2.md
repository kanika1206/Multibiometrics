# Protocol Specification v2 — Bank Multimodal Biometric Authorization
**Status:** Revised after external review of the prototype architecture (25 Oct 2026). This document supersedes the protocol-level parts of `prototype-architecture-bank.md` v1. **Amended by `protocol-spec-v3-amendments.md` (second review round, 25 Oct 2026), which wins on conflicts** — notably: evaluation sample sizes/CIs and correlated-failure measurement, a scope cut to three proven properties with an explicit deferred list, risk-adaptive authentication tiers (T0/T1/T2), offline terminology discipline, and a per-service scalability bottleneck plan. The features document is unchanged in scope; what changed is the *order and rigour*: **protocol first, models and UI second.**
**Governing principle (from the review, adopted):** This is not a collection of features. It is a security protocol, and the prototype exists to *prove specific claims* about it (§9, Claims–Evidence Matrix). Anything that does not serve a claim is deferred.

---

## 1. The five hard questions this protocol must answer
1. How does the bank know the customer authorized *this specific transaction*?
2. How do we prevent a compromised app from bypassing the biometric checks and misusing the device key?
3. How does offline authentication resist replay without a live server challenge?
4. How do we show the deepfake defences generalise beyond the attacks they were tuned on?
5. How do we prove adding customers does not proportionally increase the bank's biometric-compute cost?
Sections 2–8 answer 1–3 and 5 by design; §9–§10 answer 4 and all five by measurement.

## 2. Trust model — key security ≠ authorization security (Review §1, adopted and strengthened)
Two separate properties, designed and evaluated separately:
- **Key security:** the private key cannot be extracted. *Mechanism:* hardware-backed keystore (Android Keystore/StrongBox, iOS Secure Enclave), non-exportable keys.
- **Authorization security:** the key cannot be *used* without a genuine, intended authorization event. A hardware key alone does **not** provide this — a modified app that fakes `PASS/PASS/PASS` could otherwise ask the legitimate key to sign. v2 therefore binds key use to the platform, not to our app's say-so:

**Protocol rule T1 — Platform-gated signing.** The signing key is created with **per-use user-authentication binding**: Android Keystore `setUserAuthenticationRequired(true)` with per-use authentication (auth validity = 0 / per-use via `BiometricPrompt` + `CryptoObject`), iOS Secure Enclave key with `.biometryCurrentSet` / `.userPresence` access control. Consequence: *every signature requires a fresh platform authentication event (device biometric or device credential) enforced by the OS/secure hardware, outside our app's code.* A modified app that fabricates our custom face/voice verdicts still cannot obtain a signature silently — it must get the OS to release the key, which requires the real user's platform authentication. Our custom multimodal check remains the product's identity layer; the platform gate is the anti-bypass layer. The residual gap is stated plainly: on a *rooted/jailbroken* device both layers can be undermined, which is why T2 exists.
**Protocol rule T2 — Attestation as a bank-side gate, with honest scope.** Every enrolment and every online session presents a platform attestation verdict — Android **Play Integrity API** (app integrity, device integrity) / iOS **App Attest**. The bank verifies the verdict server-side (never trusts a client-forwarded "passed" flag), binds it to the session/challenge, and applies policy: failed/absent attestation → deny or step-up, never silent allow. **Scope statement (must appear verbatim in the paper/report):** *attestation provides evidence about the app and device environment; it does not attest that our custom face/voice models executed correctly or that every frame came from a genuine sensor.*
**Protocol rule T3 — Signed verification transcript (evidence, not proof).** The payload the device signs (§4) includes a hash of a *verification transcript*: challenge id, per-factor scores/verdicts, PAD and lip-sync scores, model names+versions, thresholds, capture-integrity signals, timestamps, and the attestation verdict reference. The bank stores this with the authorization. This makes every authorization auditable and makes silent verdict-faking *detectable in aggregate* (e.g. impossible score distributions), while we explicitly do **not** claim the transcript is trustworthy on a compromised device.
**Protocol rule T4 — Capture integrity.** Per-session: virtual-camera/emulator/root/hook signals collected at capture; capture metadata signed with a per-session key chained to the device key. A session with failed capture integrity cannot produce a *financial* authorization (it may still produce a local-access unlock, per §6's two policies).

## 3. Principals, keys and credentials
| Item | Where created/stored | Lifetime | Notes |
|---|---|---|---|
| Device signing key pair | Secure hardware on device; public key at bank | Until revoked / device retired | Per-use platform-auth binding (T1) |
| Attestation verdict | Platform service → verified by bank | Per enrolment + per online session | Bound to challenge/session id (anti-replay of verdicts) |
| Biometric template (cancelable, ~3 KB) | Device vault only, AES-256-GCM, keystore-wrapped key | Until re-enrol/delete | Never transmitted; bank holds no copy |
| Online challenge | Bank (Redis), CSPRNG | 5 min, single-use, consumed on first verify attempt | As v1 |
| **Access credential** (offline local unlock) | Device, bank-signed | **7 days** | Policy A in §6 |
| **Financial challenge pack** (offline authorization) | Bank-signed, device secure storage | **48 hours, max 5 authorizations, cumulative cap = offline framework limits** | Policy B in §6 — deliberately much stricter than v1's single 7-day pack |
| Authorization record | Bank, append-only | Permanent (audit) | State machine in §5 |

## 4. What gets signed — exact payloads (canonical, versioned)
All payloads are canonically encoded (sorted-field JSON or CBOR — pick one at build start, record it here), hashed with SHA-256, and signed with ECDSA P-256. `‖` = field separation in the canonical encoding. Any field change = new payload version.

**Online login:** `Sign( v ‖ device_id ‖ challenge_id ‖ challenge ‖ transcript_hash ‖ attestation_ref ‖ issued_at ‖ expires_at )`
**Online transaction authorization:** `Sign( v ‖ device_id ‖ challenge_id ‖ challenge ‖ tx_id ‖ amount ‖ currency ‖ payee_id ‖ payee_name_hash ‖ transcript_hash ‖ attestation_ref ‖ issued_at ‖ expires_at )`
**Offline transaction authorization:** `Sign( v ‖ device_id ‖ pack_id ‖ challenge_seq ‖ challenge ‖ tx_id ‖ amount ‖ currency ‖ payee_id ‖ device_counter ‖ transcript_hash ‖ created_at )` — queued, submitted at sync (§6).
Rules: `tx_id` is bank-issued online, or device-generated as `device_id ‖ device_counter` offline (globally unique by construction). A signature is valid for exactly the payload signed — changing amount or payee invalidates it (tested in §10, transaction-substitution test).

## 5. Authentication ≠ Authorization ≠ Execution (Review §4, adopted)
Four distinct stages, four distinct owners — the bank's execution decision is never implied by a valid signature:
```
[1] Local biometric verification      (device)   face ∧ voice ∧ challenge; PAD/lip-sync/integrity → risk signals
[2] Device-bound signing              (device)   platform-gated (T1), payload per §4
[3] Bank verification                 (bank)     signature valid? challenge fresh & unconsumed? attestation OK?
                                                  device not revoked? credential/pack not expired?
[4] Risk & policy evaluation          (bank)     account active? payee valid? limits? velocity? step-up required?
[5] Transaction authorization         (bank)     explicit bank decision: AUTHORIZED / DENIED / STEP-UP / EXPIRED
[6] Core banking execution            (bank)     only on AUTHORIZED + not previously processed (tx_id idempotency)
```
**Authorization lifecycle (state machine, every transition audited):** `CREATED → SIGNED → VERIFIED → AUTHORIZED → EXECUTED`, with terminal side-states `DENIED`, `EXPIRED`, `DUPLICATE` (same tx_id or challenge re-presented), `REVOKED-DEVICE`. A record may never skip states; the audit log is the sequence of transitions.
**Offline corollary (verbatim for the report):** *an offline signed request is evidence of an attempted authorization, not a guarantee of settlement.* At sync it enters at state `SIGNED` and must pass [3]–[5] like any other request — including duplicate, expiry and revocation checks as of sync time (and, where the payload carries it, as of signing time for limits accounting).

## 6. Offline protocol v2 — the three review issues, addressed (Review §2)
### Issue A — Pack secrecy: signing proves origin, not secrecy. Adopted + strengthened:
- Pack challenges are stored **only as individually encrypted blobs**, encrypted under a keystore-wrapped key; **exactly one** challenge is decrypted, at the moment of presentation, after capture-integrity checks (T4) pass. Future challenges never exist in plaintext in app memory or storage accessible to ordinary app components.
- A pack is **bound to one device key**; pack blobs are useless if copied to another device (decryption key never leaves secure hardware).
- Packs are issued **only to devices with a currently valid attestation verdict** — a device that becomes compromised stops receiving new packs even if its current pack has not expired.
- Honest limit (report verbatim): *on a fully compromised (rooted) device, a determined attacker may extract challenges at presentation time. The pack design limits exposure to one challenge at a time and a 48-hour financial window; it does not claim secrecy against a rooted device.*
### Issue B — Rollback of the consumed counter: the bank, not the phone, is the authority. Adopted:
- **Server ledger (authoritative):** for every device the bank records issued pack ids, accepted `challenge_seq` values, the highest accepted `device_counter`, and all processed `tx_id`s. At sync, the bank rejects: any re-presented challenge, any `device_counter` ≤ highest accepted, any duplicate `tx_id` — *regardless of what the device claims about its local state.*
- **Device side (defence in depth, not the guarantee):** consumption state kept in the most rollback-resistant store the platform offers (hardware-backed/TEE storage where available; investigate StrongBox/RPMB-backed counters on Android). Prototype must *test* rollback: snapshot app state → consume a challenge → restore snapshot → attempt reuse → the local result *and* the bank-at-sync result are both reported. If the platform cannot prevent local rollback, the report says so and points to the server ledger as the control that makes rollback unprofitable (the reused authorization is rejected at [3]/[6] and the device is flagged).
- **Tamper-evident queue:** offline authorizations are hash-chained (each record includes the previous record's hash, inside the signed payload). Deleting or editing a queued record breaks the chain and is detected at sync → device flagged, offline pocket frozen pending review.
### Issue C — Revocation while offline: two policies, measured window. Adopted:
- **Policy A — Offline local access** (app unlock, view cached data): access credential, 7-day expiry. A revoked device may retain *local access to its own cached data* until expiry — accepted, low financial risk, stated plainly.
- **Policy B — Offline financial authorization**: separate financial pack — **FROZEN CONFIGURATION (v5 §3): 48-hour expiry, max 5 authorizations, ₹500 per transaction, ₹2,000 cumulative** — fresh pack only after an online, attested session. *(The enhanced UPI Lite limits ₹1,000/₹5,000 exist in RBI's framework but are out of scope for this prototype and are not a configuration option anywhere in this design.)* Worst-case exposure of a revoked-but-offline device is therefore *bounded in time, count and rupees* — and the bound is a number we publish, not an adjective.
- **Headline measurement:** the revocation-window test (revoke at T, device offline, attempt authorizations until refusal) is a **primary evaluation result**, reported as: max elapsed time, max #authorizations, max cumulative ₹ executable after revocation. Target for the prototype config: ≤48 h, ≤5, ≤₹2,000 — measured, not asserted.

## 7. Session & online protocol (condensed, normative steps)
Enrolment: identity binding (existing account auth) → attestation verified → device key generated (T1 binding) → public key registered → 3-sample biometric enrolment on-device → transcript of enrolment signed & stored. Login: challenge issued (CSPRNG, 5-min, single-use) → attestation for session → capture (T4) → on-device verification (streaming) → platform-gated signature over §4 login payload → bank stages [3]–[5] → session token. Transaction: identical, with the §4 transaction payload and stage [6]. Attempt policy: ≤3 biometric attempts per challenge, ≤5 challenges per account per hour, exponential backoff, lock + step-up — server-enforced (fixes v1's missing throttling at the protocol level, not as an app feature).

## 8. Scalability — by construction, and what "prove" means (Review §5 Phase 4, adopted)
By construction: biometric inference is O(1) per user *on the user's device*; bank-side per-login work is: 1 Redis challenge read/consume, 1 signature verification, 1 attestation-verdict verification (cacheable per session), point-lookup account/device reads on a user-hash-sharded store, 1 async audit write. No component's cost grows with total enrolled users except storage (~200 B/user public-key records).
**Measurement discipline:** enrolled users and concurrent requests are *different axes* and are reported separately, always as a pair — e.g. "1,000,000 enrolled × 500 concurrent: p95 verify latency X ms, Y req/s/instance, error rate Z%". A 1M-row database alone proves nothing and will not be presented as a scalability result. Instance-failure behaviour (kill one verification instance mid-test) is part of every load run.

## 9. Claims–Evidence Matrix — the definition of success (Review §6, adopted as governing table)
| # | Claim | Prototype must prove | Evidence produced |
|---|---|---|---|
| C1 | Deepfake-resistant | Combined system detects the §10 attack classes at measured rates, with per-layer attribution | Attack-evaluation matrix (§10) with attempts/accepted/rejected/stepped-up per layer |
| C2 | Scalable | Bank-side cost per login is ~constant as enrolled users grow; throughput scales with instances | Load tests at 10k/100k/1M enrolled × stated concurrency; p50/p95, req/s, CPU/RAM, failure drill |
| C3 | Offline-capable | Bounded offline authorization works and its limits are measured | Airplane-mode runs; rollback test; duplicate-at-sync test; revocation-window numbers (§6) |
| C4 | Privacy-preserving | No biometric recording or template reaches the bank | Network capture inspection during all flows; backend storage inspection; data-flow audit |
| C5 | Transaction-secure | An authorization cannot be reused for a different amount/payee, or twice at all | Substitution test (alter amount/payee → signature fails); replay test (re-present → DUPLICATE); expiry test |
| C6 | Authorization-honest | The app cannot obtain signatures by faking biometric verdicts on an uncompromised device | Platform-gate test: modified/debug build returning forced PASS cannot sign without a platform auth event; attestation-failure policy test |
Every claim is either supported by its evidence row or explicitly downgraded in the report. There is no third option.

## 10. Attack-lab evaluation matrix (Review §3, adopted — replaces the "demo where everything fails")
Fixed test set, fixed thresholds (pre-registered before running), model versions recorded per run. Minimum 30 attempts per attack row (prototype floor; 100+ for the paper's headline rows) and 30 genuine attempts per condition row.
| Test | Measure (all recorded per attempt) |
|---|---|
| Genuine user, good conditions | Accept / retry / step-up / deny → genuine accept rate, FRR |
| Genuine user, poor light / noise | Same → FRR under stress, recovery-via-step-up rate |
| Photograph to camera | Attack acceptance rate; which layer(s) fired |
| Recorded video replay | Replay acceptance rate; per-layer attribution |
| Recorded voice replay | Voice replay acceptance rate |
| Synthetic/cloned voice, fresh challenge | Voice spoof acceptance rate |
| Face-swap video | Acceptance + step-up rates |
| Virtual-camera injection | Injection detection rate (capture integrity vs PAD attribution kept separate) |
| Mismatched face+voice | AV-mismatch detection rate |
| Modified app (forced PASS verdicts) | Can it obtain a signature? (C6) Attestation/integrity detection rate |
| Rollback + duplicate offline submission | Local reuse result; bank-at-sync result (must be DUPLICATE) |
| Revoked device, offline | §6 window measurements |
**Attribution rule (from the review, verbatim in spirit):** every attempt logs each layer's individual verdict *before* fusion. A rejection is credited to a layer only if that layer's own verdict was negative; "the risk engine rejected it" is not evidence that any specific detector works. **Generalisation rule (answers hard question 4):** at least two attack rows must use tools/samples *not* used during development or threshold tuning (held-out attack set — e.g. a different TTS engine and a different face-swap tool than the ones tested during building), and results on held-out attacks are reported separately from results on development attacks. A defence that only stops the attacks it was built against has demonstrated memorisation, not resistance.

## 11. Revised build order (Review §5, adopted — replaces v1 §5 ordering)
- **Phase 1 — Security foundation:** app shell, 3-sample enrolment, face/voice/challenge matching, T1 platform-gated device key + registration, challenge service, signature verification, bank stages [3]–[6] with mock core banking, audit state machine. *Exit: C4 + C5 + C6 evidence collected.*
- **Phase 2 — Differentiating security layers:** face PAD, voice anti-spoof, lip-sync, capture integrity (T4), risk fusion (allow/step-up/deny), attack lab + §10 matrix. *Exit: C1 evidence on development attacks.*
- **Phase 3 — Offline:** challenge packs (two policies, §6), hash-chained queue, sync + server ledger, expiry handling. *Exit: C3 evidence incl. rollback, duplicate, revocation-window.*
- **Phase 4 — Scalability:** load harness, staged enrolled×concurrent runs, failure drills. *Exit: C2 evidence.* Then: held-out attack evaluation (C1, generalisation) and the full claims report.

## 12. Limitations register (maintained, published with results)
1. Attestation ≠ proof our custom models ran correctly (T2 scope). Mitigated, not eliminated, by T1+T3.
2. Rooted-device attacker can extract a challenge at presentation time and undermine local state; server ledger + 48-h/₹-capped financial pack bound the damage; local rollback may be unpreventable on some platforms — measured per §10, not assumed.
3. Real-time interactive deepfakes remain the hardest class; the protocol's answer is layered detection + step-up + limits, and §10 reports that row's numbers without rounding them into a success story.
4. Offline revocation is bounded, never instant (§6 numbers).
5. Platform-gated signing (T1) ties the prototype to Android/iOS secure-hardware availability; devices without it get a reduced-assurance policy (step-up mandatory), enumerated at enrolment.
