# Evaluation Freeze — starter (Wednesday, after Tuesday's internship launch)

**Status: DRAFT ONLY — this does not freeze anything.**
It pre-fills only what is already known from the submitted v1 paper, so
Kanika does not start from a blank worksheet. Before anything counts, every
value below must be confirmed against the actual code/config at freeze time,
then copied into `evaluation-freeze-worksheet.md` and hashed as a bundle —
only the committed, hashed bundle plus the `FREEZE:` line in
`experimental-plan-v4.md` §6 counts as a freeze. No frozen Baseline 1.0 file
was edited to make this starter.

## Pre-filled from submitted v1 (confirm, don't assume)

| Threshold / item | v1 value | Source in the frozen record |
|---|---|---|
| Face identity (τf) | 0.35, cosine, 512-d embeddings | FINAL-DOCUMENT § login; MEMORY: submitted paper |
| Speaker identity (τa) | 0.30, cosine, ECAPA-TDNN 192-d, 16 kHz mono | FINAL-DOCUMENT § login |
| Challenge | 5-digit, spoken, server-issued in v1; strict AND decision across all three factors | FINAL-DOCUMENT § login |
| Decision rule | Strict AND — all three must pass | FINAL-DOCUMENT § login |

## Still blank — needs Kanika's actual code/config, not a guess

- PAD threshold, lip-sync threshold, risk / step-up thresholds
- Tier policy values (T0 / T1 / T2)
- Challenge digits / timeout for the new offline design (note: v1 used a
  server-issued challenge; the offline design replaces that — do not copy
  the v1 challenge mechanism across uncritically)
- Model files, versions and SHA-256s for configs B0–B5
- Reference device, analysis-code commit, sealed held-out attack inventory
- Solo arrangement statement (solo / two-person)

## Suggested first step (one sitting, no headline run)

1. Confirm the four v1 rows above against the current prototype code.
2. Fill the blank rows above from that same code — no tuning, no held-out data.
3. Copy the completed sheet into `evaluation-freeze-worksheet.md`, hash the
   bundle, and only then add the `FREEZE:` line to experimental-plan-v4 §6.

## What this deliberately does NOT do

- No headline evaluation, no attack run, no threshold tuning.
- No change to any Specification Baseline 1.0 file.
- The internship thread is separate: if Tuesday's portals were not yet
  applied to, Twilio and Rubrik 8166537 were still circulating in mirrors
  on Tuesday evening (27 Oct 2026, ~17:30 IST) with no published closing
  date — that remains mirror evidence, not official-portal confirmation.
