# Experimental Plan & Definitions v4 — Pre-Registration for the Headline Evaluations
**Amends:** `protocol-spec-v2.md` + `protocol-spec-v3-amendments.md`. On conflict, this document wins for everything concerning *evaluation*.
**Source:** Third external review (25 Oct 2026), point 6 A–D — four definitions to resolve **before** the design and experimental plan are approved. All four are resolved below, normatively. This document is written to be **frozen and hashed before any headline evaluation runs** (§5) — that act, not this text alone, is what makes the results publishable.
**Status:** DRAFT FOR FREEZE. Freeze checklist in §6.

---

## §A. Outcome taxonomy — what counts as a successful defence (Review A)
Every trial, attack or genuine, ends in **exactly one** outcome, assigned by rule from the per-layer log — never by impression. A trial starts when a challenge is presented and ends at a bank stage-[5] decision, challenge expiry (5 min), or a defined inconclusive event.

| Outcome | Formal definition (all conditions required) | Counts as |
|---|---|---|
| **Accepted** | The evaluated authorization path completes: identity decision = pass, no denying security verdict, risk engine = allow (no step-up demanded), bank reaches AUTHORIZED (and, in execution trials, EXECUTED) | Attack: **attack success**. Genuine: success |
| **Detected and denied** | A *named* security control's own verdict is negative (face identity, voice identity, challenge, face PAD, voice PAD, lip-sync, capture integrity, attestation, or a bank policy check) **and** that verdict is on the causal path of the final decision (the decision record lists it as a denying reason) **and** final decision = DENIED | Attack: defence success, **attributed to that control** |
| **Detected and stepped up** | No denying verdict, but a *named* security signal crosses the pre-registered step-up threshold, the risk engine demands step-up **because of that signal** (recorded), and the trial does not complete within the evaluated path (in attack trials, the attacker is assumed *not* to possess the step-up factor — OTP/PIN — so a stepped-up attack trial terminates here) | Attack: **neither accepted nor detected-and-denied** — reported as its own rate, always |
| **Risk-managed step-up** (sub-type, recorded separately) | Step-up demanded by *contextual* policy only (amount, velocity, device age) with **all security-signal scores in their normal ranges** | Explicitly **NOT detection**. Exists so a system cannot claim detection credit for its amount limits |
| **Inconclusive** | The trial cannot test the property it was meant to test, for a reason in the pre-registered list (§A.2), e.g. capture never started, attack-generation tool crashed before presentation, wrong identity claimed, recording corrupt | Excluded from that property's denominator **and** reported as a count with reasons; included in a sensitivity re-analysis (§A.3) |

**Reporting rules (normative):**
1. Every attack class reports **four rates that sum to 100%**: Accepted · Detected-and-denied · Stepped-up (detected) · Stepped-up (risk-managed) — plus the inconclusive count. *No combined "blocked rate" may appear anywhere* (paper, slides, demo) — a single merged number is precisely what the review forbade.
2. The headline security metric is **attack acceptance rate**; **detection rate** (detected-and-denied) and **step-up rate** are co-headlines, never footnotes.
3. Genuine trials use the mirror taxonomy: **Accepted first-attempt** · **Accepted after step-up/retry** · **Denied**, and we report both *first-attempt success rate* (the usability number) and *eventual success rate*. FRR is computed on Denied / (total − inconclusive), with the inconclusive count printed beside it.
4. A denial caused by a control that was *not* the intended subject of the trial (e.g. a voice-replay trial denied by face PAD because the replay setup showed a photo) is credited to the control that fired, and the trial is *also* flagged so per-class intended-control rates can be reported both ways. No silent cross-crediting.

### §A.2 Pre-registered inconclusive reasons (closed list — anything else is a Denied/Accepted as it falls)
Capture hardware/OS failure before first frame · attack-generation failure before presentation (tool log required) · subject deviated from script in a way that voids the trial definition (logged by operator at the time, not afterwards) · enrolment for the claimed identity does not exist or belongs to a different subject (operator error) · infrastructure failure (server/Redis down) mid-trial. Operator must tag the reason *during* the session; retroactive inconclusive tagging is prohibited.
### §A.3 Sensitivity rule
Headline rates are published twice: excluding inconclusive trials (primary) and counting inconclusive attack trials as Accepted / inconclusive genuine trials as Denied (worst case). If the two tell different stories about a claim, the claim is reported as not established.

---

## §B. Fair baseline for P2 (Review B) — configurations, same data, visible trade-off
**Claim under test (P2):** the layered system materially reduces joint attack acceptance vs any simpler configuration, at an acceptable genuine-user and resource cost.
**Design that makes it fair:** all detector configurations are evaluated on the **identical recorded corpus** (genuine enrolment/probe sets + attack sets, development and held-out) by running each configuration's pipeline over the same files — comparisons are *paired* on the same samples. Live-only properties (injection, platform gate, rollback, coherent real-time impersonation) are evaluated live, per configuration where the configuration changes the outcome, and labelled live/paired accordingly.

| Config | Identity (always: face ∧ voice ∧ challenge) | + Face PAD | + Voice PAD | + Lip-sync | + Capture integrity | Purpose |
|---|---|---|---|---|---|---|
| **B0 — Identity only** (= submitted v1 system) | ✓ | – | – | – | – | The honest baseline: what the layers must beat |
| B1 | ✓ | ✓ | – | – | – | Single-layer |
| B2 | ✓ | – | ✓ | – | – | Single-layer |
| B3 | ✓ | – | – | ✓ | – | Single-layer (novelty candidate, isolated) |
| B4 | ✓ | ✓ | ✓ | – | – | PAD pair |
| **B5 — Full system** | ✓ | ✓ | ✓ | ✓ | ✓ | The proposed system |
| B5−F, B5−V, B5−L, B5−C | ✓ | leave-one-out ×4 | | | | Ablations (from v3) — derived from the same runs by verdict masking where the layer is offline-scorable |

**Per-configuration reporting (one row per config, no exceptions):** per-attack-class and overall **Accepted / Detected-denied / Stepped-up rates with 95% CIs** · genuine **first-attempt success, eventual success, FRR** · **processing latency** p50/p95 per attempt (on the reference device) · **resource cost**: total model footprint (MB), peak RAM during verification, and (recorded-corpus runs) mean CPU-seconds per attempt. The result is a *trade-off table*, and the paper's P2 discussion must argue from that table — including any row where the full system looks bad.
**Paired statistics:** config-vs-config differences on the same samples use paired methods (paired bootstrap over subjects/samples; McNemar-style comparison for accept/not-accept). An unpaired CI-overlap eyeball is not an analysis.
**Pre-registered "materially better" for P2 (frozen numbers, §5):** P2 is supported iff on the **held-out** set: (i) B5 overall attack acceptance ≤ B0's by **≥ 20 percentage points** (paired 95% CI for the difference excludes 0), **and** (ii) B5 ≤ best single-layer config (B1–B3) by **≥ 5 percentage points** (paired CI excludes 0), **and** (iii) the cost stays inside the budget: FRR(B5) − FRR(B0) ≤ **+3 points**, p95 processing latency increase ≤ **+2.0 s**, total footprint ≤ **250 MB**. Failing (iii) with (i)–(ii) passing = "P2 supported as a security result, not yet as a product improvement" — that exact sentence is pre-agreed so nobody negotiates wording after seeing data.

## §C. Privacy claim, made precise and verifiable (Review C) — this replaces the broad phrase "privacy-preserving"
**The claim, restated narrowly (the only version we are allowed to make):** *"Raw biometric recordings and biometric templates do not leave the customer's device; the bank receives only the enumerated non-biometric data in Table C1; product telemetry and crash reporting contain no biometric data or biometric-derived scores."*
### Table C1 — Complete data inventory (freeze with this document; any new data element = a protocol amendment)
| Data element | Created where | Leaves device? | Bank stores? | Retention / fate |
|---|---|---|---|---|
| Raw video / audio of enrolment & login | Device | **Never** | No | Deleted immediately after feature extraction (both flows) |
| Face / speaker embeddings (raw) | Device | **Never** | No | Exist in memory; persisted only as cancelable-transformed template |
| Cancelable template (~3 KB) | Device vault | **Never** | No | Until re-enrol (old template + its key **cryptographically erased**: key destroyed, ciphertext overwritten/deleted) or device removal/account deletion (same erasure; bank-side: public key revoked & deleted, audit records per C1 note) |
| Signed payloads (§4 of spec) incl. transcript **hash** | Device → bank | Yes, by design | Yes | Authorization/audit retention per bank policy — contains **scores and verdicts, model versions, no embeddings, no media** |
| Attestation verdict | Platform → bank (verified server-side) | Yes | Yes (verdict + session binding) | Session/audit retention |
| Device metadata (model, OS, app version), IP, timestamps | Device/network | Yes | Yes | Audit retention; enumerated here so "the bank learns nothing" is never claimed — it learns *metadata*, listed |
| Product analytics events | Device → analytics | Only allow-listed event names + non-biometric fields (flow step, duration bucket, result code) | n/a | **No scores, no embeddings, no transcript content, no challenge values — enforced by an allow-list schema in code, tested in §C tests** |
| Crash reports | Device → crash service | Scrubbed: auth-module memory/media excluded; challenge values and scores are never written to logs that a crash dump could capture (logging allow-list, same schema discipline) | n/a | **Tested by forced-crash trial (§C)** |
| OS cloud backup | Device OS | Vault DB and keystore material **excluded from backup** (platform flags: Android backup exclusion rules / `allowBackup=false` for the vault; iOS keychain `ThisDeviceOnly`) | n/a | Tested by backup-restore onto a second device: enrolment must NOT transfer |
### §C verification tests (all must pass for P1's privacy row; evidence = artifacts, kept)
1. **Network inspection:** full enrol/login/transaction/offline-sync runs behind a capture proxy on a test build — artifact: capture files + a byte-search showing no media/embedding payloads (payload inventory reconciled field-by-field against Table C1).
2. **Backend inspection:** dump of every bank-side store after the runs — artifact: schema + sample records, checked against C1's "Bank stores?" column.
3. **Log audit:** automated grep of client + server logs for forbidden patterns (embedding vectors, base64 media, challenge values in plaintext on the client side, raw scores in analytics) — artifact: the pattern list + clean output.
4. **Forced-crash test:** crash forced mid-verification (debug hook) with crash reporting enabled — artifact: the actual uploaded report, inspected field-by-field.
5. **Backup test:** OS backup of device 1 restored to device 2 — expected: no usable template, no keys, enrolment absent (ThisDeviceOnly/exclusion working).
6. **Lifecycle test:** re-enrol → old template/key unrecoverable on a rooted test device image taken before and after (best-effort forensic check, method stated); remove device → bank-side public key gone/revoked and device-side vault wiped on next app start/contact.

## §D. Reproducibility & pre-registration (Review D)
### §D.1 Freeze package (created once, before headline runs; stored as a versioned, hashed bundle)
Frozen attack-class list + generation tools & versions for development attacks · held-out attack tools/samples **sealed** (generated/collected, inventoried by hash, not run, not inspected beyond inventory) · all thresholds (identity, PAD, lip-sync, risk/step-up, tier policy) in one threshold manifest · model manifest: name, source, version, SHA-256 of every model file for every config in §B · trial definitions (§A) and inconclusive list (§A.2) · metrics & formulas (§A, §B) incl. CI methods (Wilson/Clopper–Pearson for counts; subject-level bootstrap, seed **20261025**, 5,000 replicates, for corpus metrics) · success criteria (§B budgets, §D.2) · reference device spec · analysis code version (git commit).
### §D.2 Pre-registered success criteria (summary — the numbers that decide the claims)
- **P1:** §C tests 1–6 all pass (zero biometric artifacts found) **and** transaction-substitution/replay tests: 0 altered-payload acceptances, 0 duplicate executions, across all trials run.
- **P2:** §B criteria (i)+(ii)+(iii) on the held-out set.
- **P3:** duplicate/replayed offline authorizations accepted by the bank: **0**; rollback reuse accepted at sync: **0**; revocation exposure measured and within the configured bound (48 h / 5 / ₹2,000) in every revocation trial.
- **Tiers (C7):** escalation tests: 0 instances of a T0 session completing a T1/T2-reserved action without escalating; per-tier attack rows reported incl. T0-aimed attacks.
Any criterion not met is reported as not met, with the numbers. Criteria may not be edited after the freeze except through §D.3.
### §D.3 Change & deviation discipline
After the freeze: **no tuning on the held-out set, in either direction, ever** (a system change informed by held-out results converts that set into development data — if that ever happens, it must be declared and a *new* held-out set created before any further headline claim). Any other deviation (tool failure, forced config change, bug found mid-run) goes in a **deviation log**: date, what changed, why, which trials are affected, and results are reported both including and excluding affected trials where the deviation could matter. Failed and excluded trials are listed in an appendix with §A.2 reasons — the trial ledger (every trial: id, class, config, outcome, reasons) is a project artifact, published with the paper's supplementary material if the venue allows.
### §D.4 Roles & blinding (lightweight, student-project scale)
Where two people are available: the person who generates the held-out attacks is not the person who sets the thresholds. Solo: the freeze + seal-by-hash substitutes for blinding — you cannot unknowingly tune against samples you have only hashed. State which arrangement was used.

## §6. Freeze checklist (all boxes ticked = evaluations may start)
- [ ] §A taxonomy implemented in the trial logger (outcome + denying/step-up control auto-recorded)
- [ ] §B configs B0–B5 runnable on the recorded corpus; reference device documented
- [ ] Table C1 reviewed against the actual code's data flows (not the intended ones)
- [ ] Threshold manifest + model manifest generated, SHA-256s recorded
- [ ] Held-out attack set generated/collected, hashed, sealed; development set listed separately
- [ ] Success criteria (§D.2) copied verbatim into the results template — the template's claim cells are formulas over the criteria, not free text
- [ ] Freeze bundle committed & hashed; hash + date recorded here: `FREEZE: ______ (date / bundle SHA-256)`
