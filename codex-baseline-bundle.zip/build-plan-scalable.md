# Build Plan B — SCALABLE Version (bank-ready direction)
**Project:** Secure User Authentication Using Multimodal Biometrics (Draft 7) → scalable hybrid
**Goal in one line:** Serve **lakhs of users** (design targets: 10k → 100k → 1M enrolled users, load-tested in stages) by keeping the system strictly 1:1, moving biometric compute to users' devices, and making everything that stays on the server stateless — with the FIDO2/passkey + PAD additions a bank use-case requires.
**Not this plan:** fully-offline single-device operation with no server at all — that is Build Plan A (Offline). This plan keeps a server, but shrinks its job to almost nothing.
**Starting point (already built):** React + Express/Node 22 + MongoDB + Python 3.12 pipeline, face ONNX (512-d, τf = 0.35), ECAPA-TDNN speaker (192-d, τa = 0.30), external STT challenge, AES-256-GCM per-user templates with separate key vault, AND decision. Known bottlenecks from Draft 7: extraction 6.5–12.4 s/login on the server, ~147 KB template/user, no PAD (ASVspoof spoof acceptance 72–76%), challenge uses `Math.random`.
**Timeline estimate:** 10–12 weeks solo, 6–8 weeks for a 2–3 person team. Estimates, not commitments. Phases 2 and 4 are the long poles.
**Scale targets (acceptance numbers, staged):** Stage 1: 10,000 enrolled / 100 concurrent logins. Stage 2: 100,000 enrolled / 500 concurrent. Stage 3 (stretch, simulated): 1,000,000 enrolled / 1,000+ concurrent login attempts with p95 added server latency < 1 s (excluding on-device biometric time). Each stage must pass its load gate before the next begins.

---

## Architecture after this plan
```
Customer phone / laptop                                Bank / service backend
┌──────────────────────────────────┐                  ┌────────────────────────────────┐
│ Face ∧ Voice ∧ Challenge (local) │  signs bank's    │ Stateless API (load-balanced)  │
│ + face PAD + voice PAD (local)   │ ──challenge──►   │  • verify signature (public key)│
│ Private key in secure hardware   │   signature only │  • issue / consume challenge   │
│ Template: AES-GCM, key on device │                  │  • revocation & risk checks    │
└──────────────────────────────────┘                  │ Stores ONLY: public keys,      │
        ▲ enrol once (online,                            │  account status, audit logs    │
        │  bound to KYC/existing login)                  │ Sharded by hash(user_id)       │
        └──────────────────────────────────────────────└────────────────────────────────┘
Branch kiosk variant: claimed ID (card/phone no.) → gallery sharded BY BRANCH →
FAISS shortlist (top-50) → exact re-rank → voice check on survivor only. Never 1:N over the full base.
```
Server never receives or stores face/voice/templates in the target design. Biometric compute scales automatically because customers bring the compute (their phones).

---

## Phase 0 — Decisions & scale model (3–4 days)
- [ ] Freeze the non-negotiables: **1:1 only** for the customer flow (claimed identity first); 1:N allowed only for (a) branch-sharded kiosk shortlist and (b) offline duplicate-enrolment checks — each explicitly bounded.
- [ ] Write the capacity model on one page before coding: enrolled users, logins/day, peak logins/sec (assume 20% of daily logins in the peak hour), per-login server work before (≈6.5 s extraction) vs after (1 signature verification) — the model from the feasibility note: at 10M logins/day the old design needs ≈3,600 extraction cores at peak; the new design needs a handful of stateless API instances.
- [ ] Choose the passkey route: **use the platform FIDO2/WebAuthn authenticator** (phone's built-in passkey, gated by our multimodal check at enrolment/app level) vs a custom device key in the app's keystore. Recommended: platform WebAuthn for the login signature (standard, auditable) — record the decision and its trade-off; do not hand-roll signature crypto.
- **Exit gate:** capacity model + architecture diagram + decision log approved (professor, if for the paper).

## Phase 1 — Slim the data: templates, keys, storage (Week 1–2)
- [ ] **Slim template format v2:** store only mean face embedding (512-d) + speaker embedding (192-d) as binary float32 ≈ 2.8 KB raw (vs ~147 KB today, which stores 12 frame embeddings + overhead). Keep a version field; migration tool converts v1 → v2 and verifies cosine parity per user before cutover.
- [ ] **Public-key record:** per user, server stores public key + key id + status + timestamps (~200 B/user class). Do the maths in the design doc: 1M users ≈ 0.2 GB, 100M ≈ 20 GB — vs 147 GB / 14.7 TB for server-side templates at the same scales.
- [ ] **Shard the account store:** MongoDB (keep existing) with shard/partition key = hash(user_id); indexes on user_id and key id only; read path must be a single-shard point lookup (no scatter-gather in the login path).
- [ ] Fix Draft 7's challenge RNG on the server (`Math.random` → CSPRNG) — one-line class of fix, do it here, note it in the paper's errata/changes.
- **Exit gate:** v2 template live in staging; per-user server storage measured (not estimated) and reported.

## Phase 2 — Move biometric compute to the device (Weeks 2–5) ← long pole 1
- [ ] Port the pipeline to an on-device inference package: face ONNX (MobileFaceNet-class ~13 MB if the ResNet-class model is too heavy for phones — decide by benchmark, re-validate after any swap), ECAPA-TDNN exported to ONNX (~20 MB class) with the embedding-parity gate (PyTorch vs ONNX cosine > 0.99), offline digit-grammar STT for the spoken challenge (reuses Plan A's Phase 2 work if both plans are run — build this component once, share it).
- [ ] Persistent on-device model service: models load once, stay resident; warm on-device processing target ≤ 3 s on a mid-range phone (target, to be measured).
- [ ] Device key enrolment flow: generate/register the device key only *after* a successful multimodal enrolment + existing-identity binding (bank: existing account login + OTP/KYC binding; research prototype: existing account credentials). Server stores the public key from Phase 1.
- [ ] Login flow v2: server issues fresh challenge → device runs face ∧ voice ∧ challenge (+ PAD, Phase 4) locally → on success signs (challenge) — and for payments (challenge ‖ amount ‖ payee) — → server verifies signature + challenge freshness + revocation status, returns session token. Identical generic failure to the client, per-factor detail only in server logs (preserve Draft 7 behaviour).
- **Exit gate:** end-to-end login where a network capture proves no audio/video/template ever leaves the device — only the challenge request and the signature.

## Phase 3 — Make the server stateless & horizontally scalable (Weeks 4–6, overlaps Phase 2)
- [ ] Split the Express monolith into: (a) challenge service, (b) verification service (signature + status checks), (c) enrolment/admin service. Each stateless (session/challenge state in Redis with TTL — challenge 5 min, single-use, consumed on first verification attempt, as in Draft 7), each independently deployable and autoscalable behind a load balancer (Docker + any orchestrator; keep it boring).
- [ ] Revocation that works at scale: short-lived device credentials (e.g. 30–90 day validity, silently renewed on successful login) + a cached revocation list with delta updates — a lost phone dies by expiry even if it never comes back online. Define the admin revoke action and measure time-to-effective-revoke.
- [ ] Audit pipeline: login/enrolment events → append-only log store, written asynchronously (queue) so logging never blocks the login path; per-factor outcomes server-side only.
- [ ] Observability: per-stage latency histograms, login success/failure rates, challenge-expiry rate; alerts on p95 and error-rate thresholds. Draft 7's benchmark logging is the seed for this.
- **Exit gate:** kill any single API instance mid-load-test — logins keep succeeding (no single point of failure in the auth path).

## Phase 4 — Bank-grade security additions (Weeks 6–9) ← long pole 2
These are what separate "scalable demo" from "a bank could evaluate this." Skip none if bank login is the claim.
- [ ] **Face PAD:** integrate a passive liveness / anti-spoof model (ONNX, on-device) as a fourth gate alongside face/voice/challenge (AND rule extended, not replaced). Evaluate on a presentation-attack set and report APCER/BPCER in ISO/IEC 30107-3 terms.
- [ ] **Voice PAD:** integrate an anti-spoof model (AASIST-class) and re-run the ASVspoof 2019 LA/PA protocol from Draft 7 — success criterion is a *reported, materially lower* spoof acceptance than the current 72.10% / 76.17%, with the genuine FRR cost stated. No cherry-picking thresholds after seeing results; pre-register the operating point.
- [ ] **Device integrity:** rooted/jailbroken detection + platform attestation (Play Integrity / App Attest) checked at enrolment and login; failure → step-up or deny, per risk policy.
- [ ] **Risk-based step-up:** rules engine (new device, unusual time/location, high amount) → extra factor (OTP/PIN). Aligns with RBI's 2025 Directions: 2FA with at least one dynamic factor, factors independent, risk-based checks beyond the minimum allowed. Biometrics + device key cover "something you are" + "something you have"; the per-transaction signature is the dynamic proof.
- [ ] **Recovery:** lost-device flow = revoke device credential (Phase 3) + re-enrol with identity re-proofing (bank: KYC/branch; prototype: documented admin procedure, as in Draft 7 §3.9).
- **Exit gate:** security test report — spoof re-test results, attestation behaviour on a rooted test device, revoke-and-recover drill timed end-to-end.

## Phase 5 — Branch/kiosk variant: bounded 1:N (Weeks 8–10, optional if kiosk is in scope)
- [ ] Gallery per branch only (target ≤ 1,000 enrolled/terminal; ~144 KB → ~3 KB each with v2 templates, so ≈ 3 MB/branch — storage stops being the issue; accuracy discipline is the point of the cap).
- [ ] Claimed-ID first (card tap / phone number) → 1:1 check as the normal path. True 1:N only as fallback: **FAISS IVF-PQ index → top-50 shortlist → exact cosine re-rank → voice + challenge on the survivor.** Report shortlist recall@50 on the evaluation set; a miss in the shortlist is a system false-reject and must be counted as one.
- [ ] Sync: branch galleries update by delta sync overnight/on connectivity; revocations carry a priority flag and the shortest credential expiry applies at unsynced terminals. State the residual risk window in the design doc.
- **Exit gate:** kiosk simulation at 1,000-user gallery: p95 identification time and FPIR measured and reported (recall FPIR grows ≈ N × FAR — this is why the branch cap exists).

## Phase 6 — Load testing & evaluation (Weeks 10–12)
- [ ] **Load gates (k6/Locust or equivalent), in stages:** Stage 1: 10k enrolled, 100 concurrent logins. Stage 2: 100k enrolled, 500 concurrent. Stage 3: 1M enrolled (synthetic), 1,000 concurrent challenge+verify calls. Report p50/p95/p99 server latency, error rate, CPU per instance, logins/sec/instance at each stage. A stage that misses its gate gets a bottleneck report, not a pass.
- [ ] **Accuracy re-validation on the final stack:** CREMA-D face ∧ voice (compare with Draft 7: voice EER 3.15%, face∧voice FRR 6.13%), ASVspoof with PAD (Phase 4), digit-challenge accuracy with the offline STT. Same protocols, same seeds where Draft 7 used them (20260927) for comparability.
- [ ] **Cost/scale table for the paper:** server storage and per-login server cost at 10k / 100k / 1M / 100M users, this design vs Draft 7's server-matched design (the 147 GB → 0.2 GB at 1M users comparison).
- [ ] Failure drills: API instance kill (Phase 3 gate re-run under load), Redis loss (challenges fail closed, never open), clock skew on challenge expiry.
- **Exit gate:** a "Scalability Evaluation" section drafted for the paper with the stage tables — measured numbers only, targets labelled as targets.

## Risks & mitigations
| Risk | Mitigation |
|---|---|
| PAD models hurt genuine users (FRR up, login friction) | Pre-registered operating points; report the FAR/FRR trade-off honestly; risk-based step-up instead of making every login maximal |
| Phone heterogeneity breaks on-device latency/accuracy | Minimum device spec + benchmark on 3 device tiers; server-matched fallback path kept for unsupported devices (with its weaker claims stated) |
| Passkey/platform differences (Android vs iOS vs web) | Build one platform fully first (recommend Android or web/WebAuthn), others as follow-on phases, not parallel |
| Revocation window on unsynced devices/kiosks | Short-lived credentials + expiry; quantify the window, don't hide it |
| Scope creep into "national ID scale" claims | The branch cap and 1:1 rule are architectural; any 1:N-over-everything request goes back to Phase 0 for a new capacity model |
| Regulatory over-claiming | This plan builds a bank-*evaluable* prototype. Production bank use still needs the bank's infosec audit, DPDP compliance review, and certification — say so in the paper |

## Deliverables
1. Hybrid system: on-device verification app + stateless backend (Dockerised) + admin/revoke console (minimal)
2. Load-test reports for Stages 1–3 with bottleneck notes
3. Security report: PAD evaluation (ISO 30107-3 terms), ASVspoof re-test, attestation & recovery drills
4. Paper material: "Scalable Deployment" architecture + scalability evaluation section, incl. the storage/compute comparison table vs Draft 7

## What this plan deliberately does NOT do
- No fully-offline mode (server challenge + signature verification need connectivity at login — offline biometric *capture* on the device, online *proof* to the bank; a bank balance can't be checked offline anyway). For zero-network operation, see Plan A.
- No national-scale 1:N identification, no central biometric database — by design, not by omission.
